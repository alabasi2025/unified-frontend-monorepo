import{f as Ge,g as Ue,h as We,j as ce}from"./chunk-SKADEGMX.js";import"./chunk-TUQFIHML.js";import{a as it,b as ot,c as ut,f as ct}from"./chunk-IDXZHCIE.js";import"./chunk-TQCWXNJX.js";import"./chunk-LV5ZAQ3Q.js";import{a as mt,b as he}from"./chunk-BQZCJOXK.js";import"./chunk-SO7JL3TG.js";import"./chunk-XXH5K42U.js";import"./chunk-DIZVUWJX.js";import{r as fe}from"./chunk-YJST2TT3.js";import{$ as A,$b as ze,Ab as B,Ad as L,B as Se,Bb as ae,Cb as $,Db as Re,E as Le,Eb as N,Ed as pe,Fd as de,Gb as s,Hb as He,Hd as Je,Ib as $e,Ic as je,Jb as D,Jc as me,Jd as Xe,Kb as se,Kc as Qe,Lb as C,Lc as ue,Ma as re,Mb as T,Na as Fe,Nc as q,Pa as u,Pb as J,Rc as te,Sb as z,Tb as d,Td as ne,Ua as k,Ub as h,Ud as G,Vb as V,W as oe,Wb as Ne,X as Pe,Xd as Ye,Ya as Ae,Yd as et,Z as we,Za as v,Zd as be,a as Ce,ac as X,b as Te,cb as w,cc as Y,db as Ve,ea as I,ee as K,fa as f,fb as H,fe as _e,ga as M,gb as Ke,ge as tt,hb as l,hd as j,he as Ie,ia as Ee,id as F,j as Me,je as nt,kc as ee,le as rt,na as W,nb as x,oe as at,pc as Ze,pe as st,ra as R,sb as a,ta as Be,tb as p,ub as c,uc as qe,ud as le,vb as _,wc as S,xa as De,xc as Z,yb as Oe,yd as Q,z as ke,zb as E}from"./chunk-RDKUJFH5.js";var ht=["data-p-icon","bars"],pt=(()=>{class i extends nt{static \u0275fac=(()=>{let e;return function(n){return(e||(e=R(i)))(n||i)}})();static \u0275cmp=w({type:i,selectors:[["","data-p-icon","bars"]],features:[H],attrs:ht,decls:1,vars:0,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M13.3226 3.6129H0.677419C0.497757 3.6129 0.325452 3.54152 0.198411 3.41448C0.0713707 3.28744 0 3.11514 0 2.93548C0 2.75581 0.0713707 2.58351 0.198411 2.45647C0.325452 2.32943 0.497757 2.25806 0.677419 2.25806H13.3226C13.5022 2.25806 13.6745 2.32943 13.8016 2.45647C13.9286 2.58351 14 2.75581 14 2.93548C14 3.11514 13.9286 3.28744 13.8016 3.41448C13.6745 3.54152 13.5022 3.6129 13.3226 3.6129ZM13.3226 7.67741H0.677419C0.497757 7.67741 0.325452 7.60604 0.198411 7.479C0.0713707 7.35196 0 7.17965 0 6.99999C0 6.82033 0.0713707 6.64802 0.198411 6.52098C0.325452 6.39394 0.497757 6.32257 0.677419 6.32257H13.3226C13.5022 6.32257 13.6745 6.39394 13.8016 6.52098C13.9286 6.64802 14 6.82033 14 6.99999C14 7.17965 13.9286 7.35196 13.8016 7.479C13.6745 7.60604 13.5022 7.67741 13.3226 7.67741ZM0.677419 11.7419H13.3226C13.5022 11.7419 13.6745 11.6706 13.8016 11.5435C13.9286 11.4165 14 11.2442 14 11.0645C14 10.8848 13.9286 10.7125 13.8016 10.5855C13.6745 10.4585 13.5022 10.3871 13.3226 10.3871H0.677419C0.497757 10.3871 0.325452 10.4585 0.198411 10.5855C0.0713707 10.7125 0 10.8848 0 11.0645C0 11.2442 0.0713707 11.4165 0.198411 11.5435C0.325452 11.6706 0.497757 11.7419 0.677419 11.7419Z","fill","currentColor"]],template:function(t,n){t&1&&(M(),Oe(0,"path",0))},encapsulation:2})}return i})();var dt=`
    .p-menubar {
        display: flex;
        align-items: center;
        background: dt('menubar.background');
        border: 1px solid dt('menubar.border.color');
        border-radius: dt('menubar.border.radius');
        color: dt('menubar.color');
        padding: dt('menubar.padding');
        gap: dt('menubar.gap');
    }

    .p-menubar-start,
    .p-megamenu-end {
        display: flex;
        align-items: center;
    }

    .p-menubar-root-list,
    .p-menubar-submenu {
        display: flex;
        margin: 0;
        padding: 0;
        list-style: none;
        outline: 0 none;
    }

    .p-menubar-root-list {
        align-items: center;
        flex-wrap: wrap;
        gap: dt('menubar.gap');
    }

    .p-menubar-root-list > .p-menubar-item > .p-menubar-item-content {
        border-radius: dt('menubar.base.item.border.radius');
    }

    .p-menubar-root-list > .p-menubar-item > .p-menubar-item-content > .p-menubar-item-link {
        padding: dt('menubar.base.item.padding');
    }

    .p-menubar-item-content {
        transition:
            background dt('menubar.transition.duration'),
            color dt('menubar.transition.duration');
        border-radius: dt('menubar.item.border.radius');
        color: dt('menubar.item.color');
    }

    .p-menubar-item-link {
        cursor: pointer;
        display: flex;
        align-items: center;
        text-decoration: none;
        overflow: hidden;
        position: relative;
        color: inherit;
        padding: dt('menubar.item.padding');
        gap: dt('menubar.item.gap');
        user-select: none;
        outline: 0 none;
    }

    .p-menubar-item-label {
        line-height: 1;
    }

    .p-menubar-item-icon {
        color: dt('menubar.item.icon.color');
    }

    .p-menubar-submenu-icon {
        color: dt('menubar.submenu.icon.color');
        margin-left: auto;
        font-size: dt('menubar.submenu.icon.size');
        width: dt('menubar.submenu.icon.size');
        height: dt('menubar.submenu.icon.size');
    }

    .p-menubar-submenu .p-menubar-submenu-icon:dir(rtl) {
        margin-left: 0;
        margin-right: auto;
    }

    .p-menubar-item.p-focus > .p-menubar-item-content {
        color: dt('menubar.item.focus.color');
        background: dt('menubar.item.focus.background');
    }

    .p-menubar-item.p-focus > .p-menubar-item-content .p-menubar-item-icon {
        color: dt('menubar.item.icon.focus.color');
    }

    .p-menubar-item.p-focus > .p-menubar-item-content .p-menubar-submenu-icon {
        color: dt('menubar.submenu.icon.focus.color');
    }

    .p-menubar-item:not(.p-disabled) > .p-menubar-item-content:hover {
        color: dt('menubar.item.focus.color');
        background: dt('menubar.item.focus.background');
    }

    .p-menubar-item:not(.p-disabled) > .p-menubar-item-content:hover .p-menubar-item-icon {
        color: dt('menubar.item.icon.focus.color');
    }

    .p-menubar-item:not(.p-disabled) > .p-menubar-item-content:hover .p-menubar-submenu-icon {
        color: dt('menubar.submenu.icon.focus.color');
    }

    .p-menubar-item-active > .p-menubar-item-content {
        color: dt('menubar.item.active.color');
        background: dt('menubar.item.active.background');
    }

    .p-menubar-item-active > .p-menubar-item-content .p-menubar-item-icon {
        color: dt('menubar.item.icon.active.color');
    }

    .p-menubar-item-active > .p-menubar-item-content .p-menubar-submenu-icon {
        color: dt('menubar.submenu.icon.active.color');
    }

    .p-menubar-submenu {
        display: none;
        position: absolute;
        min-width: 12.5rem;
        z-index: 1;
        background: dt('menubar.submenu.background');
        border: 1px solid dt('menubar.submenu.border.color');
        border-radius: dt('menubar.submenu.border.radius');
        box-shadow: dt('menubar.submenu.shadow');
        color: dt('menubar.submenu.color');
        flex-direction: column;
        padding: dt('menubar.submenu.padding');
        gap: dt('menubar.submenu.gap');
    }

    .p-menubar-submenu .p-menubar-separator {
        border-block-start: 1px solid dt('menubar.separator.border.color');
    }

    .p-menubar-submenu .p-menubar-item {
        position: relative;
    }

    .p-menubar-submenu > .p-menubar-item-active > .p-menubar-submenu {
        display: block;
        left: 100%;
        top: 0;
    }

    .p-menubar-end {
        margin-left: auto;
        align-self: center;
    }

    .p-menubar-end:dir(rtl) {
        margin-left: 0;
        margin-right: auto;
    }

    .p-menubar-button {
        display: none;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        width: dt('menubar.mobile.button.size');
        height: dt('menubar.mobile.button.size');
        position: relative;
        color: dt('menubar.mobile.button.color');
        border: 0 none;
        background: transparent;
        border-radius: dt('menubar.mobile.button.border.radius');
        transition:
            background dt('menubar.transition.duration'),
            color dt('menubar.transition.duration'),
            outline-color dt('menubar.transition.duration');
        outline-color: transparent;
    }

    .p-menubar-button:hover {
        color: dt('menubar.mobile.button.hover.color');
        background: dt('menubar.mobile.button.hover.background');
    }

    .p-menubar-button:focus-visible {
        box-shadow: dt('menubar.mobile.button.focus.ring.shadow');
        outline: dt('menubar.mobile.button.focus.ring.width') dt('menubar.mobile.button.focus.ring.style') dt('menubar.mobile.button.focus.ring.color');
        outline-offset: dt('menubar.mobile.button.focus.ring.offset');
    }

    .p-menubar-mobile {
        position: relative;
    }

    .p-menubar-mobile .p-menubar-button {
        display: flex;
    }

    .p-menubar-mobile .p-menubar-root-list {
        position: absolute;
        display: none;
        width: 100%;
        flex-direction: column;
        top: 100%;
        left: 0;
        z-index: 1;
        padding: dt('menubar.submenu.padding');
        background: dt('menubar.submenu.background');
        border: 1px solid dt('menubar.submenu.border.color');
        box-shadow: dt('menubar.submenu.shadow');
        border-radius: dt('menubar.submenu.border.radius');
        gap: dt('menubar.submenu.gap');
    }

    .p-menubar-mobile .p-menubar-root-list:dir(rtl) {
        left: auto;
        right: 0;
    }

    .p-menubar-mobile .p-menubar-root-list > .p-menubar-item > .p-menubar-item-content > .p-menubar-item-link {
        padding: dt('menubar.item.padding');
    }

    .p-menubar-mobile-active .p-menubar-root-list {
        display: flex;
    }

    .p-menubar-mobile .p-menubar-root-list .p-menubar-item {
        width: 100%;
        position: static;
    }

    .p-menubar-mobile .p-menubar-root-list .p-menubar-separator {
        border-block-start: 1px solid dt('menubar.separator.border.color');
    }

    .p-menubar-mobile .p-menubar-root-list > .p-menubar-item > .p-menubar-item-content .p-menubar-submenu-icon {
        margin-left: auto;
        transition: transform 0.2s;
    }

    .p-menubar-mobile .p-menubar-root-list > .p-menubar-item > .p-menubar-item-content .p-menubar-submenu-icon:dir(rtl),
    .p-menubar-mobile .p-menubar-submenu-icon:dir(rtl) {
        margin-left: 0;
        margin-right: auto;
    }

    .p-menubar-mobile .p-menubar-root-list > .p-menubar-item-active > .p-menubar-item-content .p-menubar-submenu-icon {
        transform: rotate(-180deg);
    }

    .p-menubar-mobile .p-menubar-submenu .p-menubar-submenu-icon {
        transition: transform 0.2s;
        transform: rotate(90deg);
    }

    .p-menubar-mobile .p-menubar-item-active > .p-menubar-item-content .p-menubar-submenu-icon {
        transform: rotate(-90deg);
    }

    .p-menubar-mobile .p-menubar-submenu {
        width: 100%;
        position: static;
        box-shadow: none;
        border: 0 none;
        padding-inline-start: dt('menubar.submenu.mobile.indent');
        padding-inline-end: 0;
    }
`;var _t=(i,m)=>({instance:i,processedItem:m}),xt=()=>({exact:!1}),yt=(i,m)=>({$implicit:i,root:m});function vt(i,m){if(i&1&&_(0,"li",6),i&2){let e=s().$implicit,t=s();z(t.getItemProp(e,"style")),d(t.cn(t.cx("separator"),e==null?null:e.styleClass)),a("pBind",t.ptm("separator")),x("id",t.getItemId(e))}}function Ct(i,m){if(i&1&&_(0,"span",17),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();z(o.getItemProp(t,"iconStyle")),d(o.cn(o.cx("itemIcon"),o.getItemProp(t,"icon"))),a("pBind",o.getPTOptions(t,n,"itemIcon")),x("tabindex",-1)}}function Tt(i,m){if(i&1&&(p(0,"span",18),h(1),c()),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.cx("itemLabel")),a("id",o.getItemLabelId(t))("pBind",o.getPTOptions(t,n,"itemLabel")),u(),Ne(" ",o.getItemLabel(t)," ")}}function Mt(i,m){if(i&1&&_(0,"span",19),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.cx("itemLabel")),a("innerHTML",o.getItemLabel(t),re)("id",o.getItemLabelId(t))("pBind",o.getPTOptions(t,n,"itemLabel"))}}function kt(i,m){if(i&1&&_(0,"p-badge",20),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.getItemProp(t,"badgeStyleClass")),a("value",o.getItemProp(t,"badge"))("pt",o.getPTOptions(t,n,"pcBadge"))}}function St(i,m){if(i&1&&(M(),_(0,"svg",24)),i&2){let e=s(6),t=e.$implicit,n=e.index,o=s();d(o.cx("submenuIcon")),a("pBind",o.getPTOptions(t,n,"submenuIcon"))}}function Lt(i,m){if(i&1&&(M(),_(0,"svg",25)),i&2){let e=s(6),t=e.$implicit,n=e.index,o=s();d(o.cx("submenuIcon")),a("pBind",o.getPTOptions(t,n,"submenuIcon"))}}function Pt(i,m){if(i&1&&(E(0),l(1,St,1,3,"svg",22)(2,Lt,1,3,"svg",23),B()),i&2){let e=s(6);u(),a("ngIf",e.root),u(),a("ngIf",!e.root)}}function wt(i,m){}function Et(i,m){i&1&&l(0,wt,0,0,"ng-template")}function Bt(i,m){if(i&1&&(E(0),l(1,Pt,3,2,"ng-container",9)(2,Et,1,0,null,21),B()),i&2){let e=s(5);u(),a("ngIf",!e.submenuiconTemplate),u(),a("ngTemplateOutlet",e.submenuiconTemplate)}}function Dt(i,m){if(i&1&&(p(0,"a",13),l(1,Ct,1,6,"span",14)(2,Tt,2,5,"span",15)(3,Mt,1,5,"ng-template",null,1,ee)(5,kt,1,4,"p-badge",16)(6,Bt,3,2,"ng-container",9),c()),i&2){let e=J(4),t=s(3),n=t.$implicit,o=t.index,r=s();d(r.cx("itemLink")),a("pBind",r.getPTOptions(n,o,"itemLink")),x("href",r.getItemProp(n,"url"),Fe)("data-automationid",r.getItemProp(n,"automationId"))("target",r.getItemProp(n,"target"))("tabindex",-1),u(),a("ngIf",r.getItemProp(n,"icon")),u(),a("ngIf",r.getItemProp(n,"escape"))("ngIfElse",e),u(3),a("ngIf",r.getItemProp(n,"badge")),u(),a("ngIf",r.isItemGroup(n))}}function Ft(i,m){if(i&1&&_(0,"span",29),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.cn(o.cx("itemIcon"),o.getItemProp(t,"icon"))),a("ngStyle",o.getItemProp(t,"iconStyle"))("pBind",o.getPTOptions(t,n,"itemIcon")),x("tabindex",-1)}}function At(i,m){if(i&1&&(p(0,"span",17),h(1),c()),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.cx("itemLabel")),a("pBind",o.getPTOptions(t,n,"itemLabel")),u(),V(o.getItemLabel(t))}}function Vt(i,m){if(i&1&&_(0,"span",30),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.cx("itemLabel")),a("innerHTML",o.getItemLabel(t),re)("pBind",o.getPTOptions(t,n,"itemLabel"))}}function Kt(i,m){if(i&1&&_(0,"p-badge",20),i&2){let e=s(4),t=e.$implicit,n=e.index,o=s();d(o.getItemProp(t,"badgeStyleClass")),a("value",o.getItemProp(t,"badge"))("pt",o.getPTOptions(t,n,"pcBadge"))}}function Ot(i,m){if(i&1&&(M(),_(0,"svg",24)),i&2){let e=s(6),t=e.$implicit,n=e.index,o=s();d(o.cx("submenuIcon")),a("pBind",o.getPTOptions(t,n,"submenuIcon"))}}function Rt(i,m){if(i&1&&(M(),_(0,"svg",25)),i&2){let e=s(6),t=e.$implicit,n=e.index,o=s();d(o.cx("submenuIcon")),a("pBind",o.getPTOptions(t,n,"submenuIcon"))}}function Ht(i,m){if(i&1&&(E(0),l(1,Ot,1,3,"svg",22)(2,Rt,1,3,"svg",23),B()),i&2){let e=s(6);u(),a("ngIf",e.root),u(),a("ngIf",!e.root)}}function $t(i,m){}function Nt(i,m){i&1&&l(0,$t,0,0,"ng-template")}function zt(i,m){if(i&1&&(E(0),l(1,Ht,3,2,"ng-container",9)(2,Nt,1,0,null,21),B()),i&2){let e=s(5);u(),a("ngIf",!e.submenuiconTemplate),u(),a("ngTemplateOutlet",e.submenuiconTemplate)}}function Zt(i,m){if(i&1&&(p(0,"a",26),l(1,Ft,1,5,"span",27)(2,At,2,4,"span",28)(3,Vt,1,4,"ng-template",null,2,ee)(5,Kt,1,4,"p-badge",16)(6,zt,3,2,"ng-container",9),c()),i&2){let e=J(4),t=s(3),n=t.$implicit,o=t.index,r=s();d(r.cx("itemLink")),a("routerLink",r.getItemProp(n,"routerLink"))("queryParams",r.getItemProp(n,"queryParams"))("routerLinkActive","p-menubar-item-link-active")("routerLinkActiveOptions",r.getItemProp(n,"routerLinkActiveOptions")||X(21,xt))("target",r.getItemProp(n,"target"))("fragment",r.getItemProp(n,"fragment"))("queryParamsHandling",r.getItemProp(n,"queryParamsHandling"))("preserveFragment",r.getItemProp(n,"preserveFragment"))("skipLocationChange",r.getItemProp(n,"skipLocationChange"))("replaceUrl",r.getItemProp(n,"replaceUrl"))("state",r.getItemProp(n,"state"))("pBind",r.getPTOptions(n,o,"itemLink")),x("data-automationid",r.getItemProp(n,"automationId"))("tabindex",-1),u(),a("ngIf",r.getItemProp(n,"icon")),u(),a("ngIf",r.getItemProp(n,"escape"))("ngIfElse",e),u(3),a("ngIf",r.getItemProp(n,"badge")),u(),a("ngIf",r.isItemGroup(n))}}function qt(i,m){if(i&1&&(E(0),l(1,Dt,7,12,"a",11)(2,Zt,7,22,"a",12),B()),i&2){let e=s(2).$implicit,t=s();u(),a("ngIf",!t.getItemProp(e,"routerLink")),u(),a("ngIf",t.getItemProp(e,"routerLink"))}}function jt(i,m){}function Qt(i,m){i&1&&l(0,jt,0,0,"ng-template")}function Gt(i,m){if(i&1&&(E(0),l(1,Qt,1,0,null,31),B()),i&2){let e=s(2).$implicit,t=s();u(),a("ngTemplateOutlet",t.itemTemplate)("ngTemplateOutletContext",Y(2,yt,e.item,t.root))}}function Ut(i,m){if(i&1){let e=$();p(0,"ul",32),N("itemClick",function(n){I(e);let o=s(3);return f(o.itemClick.emit(n))})("itemMouseEnter",function(n){I(e);let o=s(3);return f(o.onItemMouseEnter(n))}),c()}if(i&2){let e=s(2).$implicit,t=s();a("itemTemplate",t.itemTemplate)("items",e.items)("mobileActive",t.mobileActive)("autoDisplay",t.autoDisplay)("menuId",t.menuId)("activeItemPath",t.activeItemPath)("focusedItemId",t.focusedItemId)("level",t.level+1)("inlineStyles",t.sx("submenu",!0,Y(12,_t,t,e)))("pt",t.pt())("pBind",t.ptm("submenu")),x("aria-labelledby",t.getItemLabelId(e))}}function Wt(i,m){if(i&1){let e=$();p(0,"li",7,0)(2,"div",8),N("click",function(n){I(e);let o=s().$implicit,r=s();return f(r.onItemClick(n,o))})("mouseenter",function(n){I(e);let o=s().$implicit,r=s();return f(r.onItemMouseEnter({$event:n,processedItem:o}))}),l(3,qt,3,2,"ng-container",9)(4,Gt,2,5,"ng-container",9),c(),l(5,Ut,1,15,"ul",10),c()}if(i&2){let e=s(),t=e.$implicit,n=e.index,o=s();z(o.getItemProp(t,"style")),d(o.cn(o.cx("item",Y(22,_t,o,t)),o.getItemProp(t,"styleClass"))),a("pBind",o.getPTOptions(t,n,"item"))("tooltipOptions",o.getItemProp(t,"tooltipOptions")),x("id",o.getItemId(t))("data-p-highlight",o.isItemActive(t))("data-p-focused",o.isItemFocused(t))("data-p-disabled",o.isItemDisabled(t))("aria-label",o.getItemLabel(t))("aria-disabled",o.isItemDisabled(t)||void 0)("aria-haspopup",o.isItemGroup(t)&&!o.getItemProp(t,"to")?"menu":void 0)("aria-expanded",o.isItemGroup(t)?o.isItemActive(t):void 0)("aria-setsize",o.getAriaSetSize())("aria-posinset",o.getAriaPosInset(n)),u(2),d(o.cx("itemContent")),a("pBind",o.getPTOptions(t,n,"itemContent")),u(),a("ngIf",!o.itemTemplate),u(),a("ngIf",o.itemTemplate),u(),a("ngIf",o.isItemVisible(t)&&o.isItemGroup(t))}}function Jt(i,m){if(i&1&&l(0,vt,1,6,"li",4)(1,Wt,6,25,"li",5),i&2){let e=m.$implicit,t=s();a("ngIf",t.isItemVisible(e)&&t.getItemProp(e,"separator")),u(),a("ngIf",t.isItemVisible(e)&&!t.getItemProp(e,"separator"))}}var Xt=["start"],Yt=["end"],en=["item"],tn=["menuicon"],nn=["submenuicon"],on=["menubutton"],rn=["rootmenu"],an=["*"];function sn(i,m){i&1&&ae(0)}function mn(i,m){if(i&1&&(p(0,"div",7),l(1,sn,1,0,"ng-container",8),c()),i&2){let e=s();d(e.cx("start")),a("pBind",e.ptm("start")),u(),a("ngTemplateOutlet",e.startTemplate||e._startTemplate)}}function un(i,m){if(i&1&&(M(),_(0,"svg",11)),i&2){let e=s(2);a("pBind",e.ptm("buttonIcon"))}}function cn(i,m){}function ln(i,m){i&1&&l(0,cn,0,0,"ng-template")}function pn(i,m){if(i&1){let e=$();p(0,"a",9,2),N("click",function(n){I(e);let o=s();return f(o.menuButtonClick(n))})("keydown",function(n){I(e);let o=s();return f(o.menuButtonKeydown(n))}),l(2,un,1,1,"svg",10)(3,ln,1,0,null,8),c()}if(i&2){let e=s();d(e.cx("button")),a("pBind",e.ptm("button")),x("aria-haspopup",!!(e.model.length&&e.model.length>0))("aria-expanded",e.mobileActive)("aria-controls",e.id)("aria-label",e.config.translation.aria.navigation),u(2),a("ngIf",!e.menuIconTemplate&&!e._menuIconTemplate),u(),a("ngTemplateOutlet",e.menuIconTemplate||e._menuIconTemplate)}}function dn(i,m){i&1&&ae(0)}function bn(i,m){if(i&1&&(p(0,"div",7),l(1,dn,1,0,"ng-container",8),c()),i&2){let e=s();d(e.cx("end")),a("pBind",e.ptm("end")),u(),a("ngTemplateOutlet",e.endTemplate||e._endTemplate)}}function _n(i,m){if(i&1&&(p(0,"div"),$e(1),c()),i&2){let e=s();d(e.cx("end"))}}var In={submenu:({instance:i,processedItem:m})=>({display:i.isItemActive(m)?"flex":"none"})},fn={root:({instance:i})=>["p-menubar p-component",{"p-menubar-mobile":i.queryMatches,"p-menubar-mobile-active":i.mobileActive}],start:"p-menubar-start",button:"p-menubar-button",rootList:"p-menubar-root-list",item:({instance:i,processedItem:m})=>["p-menubar-item",{"p-menubar-item-active":i.isItemActive(m),"p-focus":i.isItemFocused(m),"p-disabled":i.isItemDisabled(m)}],itemContent:"p-menubar-item-content",itemLink:"p-menubar-item-link",itemIcon:"p-menubar-item-icon",itemLabel:"p-menubar-item-label",submenuIcon:"p-menubar-submenu-icon",submenu:"p-menubar-submenu",separator:"p-menubar-separator",end:"p-menubar-end"},ge=(()=>{class i extends Ye{name="menubar";style=dt;classes=fn;inlineStyles=In;static \u0275fac=(()=>{let e;return function(n){return(e||(e=R(i)))(n||i)}})();static \u0275prov=oe({token:i,factory:i.\u0275fac})}return i})();var bt=new we("MENUBAR_INSTANCE"),xe=(()=>{class i{autoHide;autoHideDelay;mouseLeaves=new Me;mouseLeft$=this.mouseLeaves.pipe(Le(()=>ke(this.autoHideDelay)),Se(e=>this.autoHide&&e));static \u0275fac=function(t){return new(t||i)};static \u0275prov=oe({token:i,factory:i.\u0275fac})}return i})(),hn=(()=>{class i extends be{items;itemTemplate;root=!1;autoZIndex=!0;baseZIndex=0;mobileActive;autoDisplay;menuId;ariaLabel;ariaLabelledBy;level=0;focusedItemId;activeItemPath;inlineStyles;submenuiconTemplate;itemClick=new k;itemMouseEnter=new k;menuFocus=new k;menuBlur=new k;menuKeydown=new k;mouseLeaveSubscriber;menubarService=A(xe);_componentStyle=A(ge);hostName="Menubar";onInit(){this.mouseLeaveSubscriber=this.menubarService.mouseLeft$.subscribe(()=>{this.cd.markForCheck()})}onItemClick(e,t){this.getItemProp(t,"command",{originalEvent:e,item:t.item}),this.itemClick.emit({originalEvent:e,processedItem:t,isFocus:!0})}getItemProp(e,t,n=null){return e&&e.item?de(e.item[t],n):void 0}getItemId(e){return e.item&&e.item?.id?e.item.id:`${this.menuId}_${e.key}`}getItemLabelId(e){return`${this.menuId}_${e.key}_label`}getItemLabel(e){return this.getItemProp(e,"label")}isItemVisible(e){return this.getItemProp(e,"visible")!==!1}isItemActive(e){return this.activeItemPath?this.activeItemPath.some(t=>t.key===e.key):!1}isItemDisabled(e){return this.getItemProp(e,"disabled")}isItemFocused(e){return this.focusedItemId===this.getItemId(e)}isItemGroup(e){return L(e.items)}getAriaSetSize(){return this.items.filter(e=>this.isItemVisible(e)&&!this.getItemProp(e,"separator")).length}getAriaPosInset(e){return e-this.items.slice(0,e).filter(t=>this.isItemVisible(t)&&this.getItemProp(t,"separator")).length+1}onItemMouseEnter(e){if(this.autoDisplay){let{event:t,processedItem:n}=e;this.itemMouseEnter.emit({originalEvent:t,processedItem:n})}}getPTOptions(e,t,n){return this.ptm(n,{context:{item:e.item,index:t,active:this.isItemActive(e),focused:this.isItemFocused(e),disabled:this.isItemDisabled(e),level:this.level}})}onDestroy(){this.mouseLeaveSubscriber?.unsubscribe()}static \u0275fac=(()=>{let e;return function(n){return(e||(e=R(i)))(n||i)}})();static \u0275cmp=w({type:i,selectors:[["p-menubarSub"],["p-menubarsub"],["","pMenubarSub",""]],hostAttrs:["role","menubar"],hostVars:6,hostBindings:function(t,n){t&2&&(Re("id",n.root?n.menuId:null),x("aria-activedescendant",n.focusedItemId),z(n.inlineStyles),d(n.level===0?n.cx("rootList"):n.cx("submenu")))},inputs:{items:"items",itemTemplate:"itemTemplate",root:[2,"root","root",S],autoZIndex:[2,"autoZIndex","autoZIndex",S],baseZIndex:[2,"baseZIndex","baseZIndex",Z],mobileActive:[2,"mobileActive","mobileActive",S],autoDisplay:[2,"autoDisplay","autoDisplay",S],menuId:"menuId",ariaLabel:"ariaLabel",ariaLabelledBy:"ariaLabelledBy",level:[2,"level","level",Z],focusedItemId:"focusedItemId",activeItemPath:"activeItemPath",inlineStyles:"inlineStyles",submenuiconTemplate:"submenuiconTemplate"},outputs:{itemClick:"itemClick",itemMouseEnter:"itemMouseEnter",menuFocus:"menuFocus",menuBlur:"menuBlur",menuKeydown:"menuKeydown"},features:[H],decls:1,vars:1,consts:[["listItem",""],["htmlLabel",""],["htmlRouteLabel",""],["ngFor","",3,"ngForOf"],["role","separator",3,"style","class","pBind",4,"ngIf"],["role","menuitem","pTooltip","",3,"style","class","pBind","tooltipOptions",4,"ngIf"],["role","separator",3,"pBind"],["role","menuitem","pTooltip","",3,"pBind","tooltipOptions"],[3,"click","mouseenter","pBind"],[4,"ngIf"],["pMenubarSub","",3,"itemTemplate","items","mobileActive","autoDisplay","menuId","activeItemPath","focusedItemId","level","inlineStyles","pt","pBind","itemClick","itemMouseEnter",4,"ngIf"],["pRipple","",3,"class","pBind",4,"ngIf"],["pRipple","",3,"routerLink","queryParams","routerLinkActive","routerLinkActiveOptions","target","class","fragment","queryParamsHandling","preserveFragment","skipLocationChange","replaceUrl","state","pBind",4,"ngIf"],["pRipple","",3,"pBind"],[3,"class","style","pBind",4,"ngIf"],[3,"class","id","pBind",4,"ngIf","ngIfElse"],[3,"class","value","pt",4,"ngIf"],[3,"pBind"],[3,"id","pBind"],[3,"innerHTML","id","pBind"],[3,"value","pt"],[4,"ngTemplateOutlet"],["data-p-icon","angle-down",3,"class","pBind",4,"ngIf"],["data-p-icon","angle-right",3,"class","pBind",4,"ngIf"],["data-p-icon","angle-down",3,"pBind"],["data-p-icon","angle-right",3,"pBind"],["pRipple","",3,"routerLink","queryParams","routerLinkActive","routerLinkActiveOptions","target","fragment","queryParamsHandling","preserveFragment","skipLocationChange","replaceUrl","state","pBind"],[3,"class","ngStyle","pBind",4,"ngIf"],[3,"class","pBind",4,"ngIf","ngIfElse"],[3,"ngStyle","pBind"],[3,"innerHTML","pBind"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["pMenubarSub","",3,"itemClick","itemMouseEnter","itemTemplate","items","mobileActive","autoDisplay","menuId","activeItemPath","focusedItemId","level","inlineStyles","pt","pBind"]],template:function(t,n){t&1&&l(0,Jt,2,2,"ng-template",3),t&2&&a("ngForOf",n.items)},dependencies:[i,q,je,me,ue,Qe,ce,Ue,We,rt,he,mt,K,it,ot,Ie,tt,G,_e],encapsulation:2})}return i})(),ye=(()=>{class i extends be{document;platformId;el;renderer;cd;menubarService;$pcMenubar=A(bt,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=A(K,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}set model(e){this._model=e,this._processedItems=this.createProcessedItems(this._model||[])}get model(){return this._model}styleClass;autoZIndex=!0;baseZIndex=0;autoDisplay=!0;autoHide;breakpoint="960px";autoHideDelay=100;id;ariaLabel;ariaLabelledBy;onFocus=new k;onBlur=new k;menubutton;rootmenu;mobileActive;matchMediaListener;query;queryMatches;outsideClickListener;resizeListener;mouseLeaveSubscriber;dirty=!1;focused=!1;activeItemPath=W([]);number=W(0);focusedItemInfo=W({index:-1,level:0,parentKey:"",item:null});searchValue="";searchTimeout;_processedItems;_componentStyle=A(ge);_model;get visibleItems(){let e=this.activeItemPath().find(t=>t.key===this.focusedItemInfo().parentKey);return e?e.items:this.processedItems}get processedItems(){return(!this._processedItems||!this._processedItems.length)&&(this._processedItems=this.createProcessedItems(this.model||[])),this._processedItems}get focusedItemId(){let e=this.focusedItemInfo();return e.item&&e.item?.id?e.item.id:e.index!==-1?`${this.id}${L(e.parentKey)?"_"+e.parentKey:""}_${e.index}`:null}constructor(e,t,n,o,r,b){super(),this.document=e,this.platformId=t,this.el=n,this.renderer=o,this.cd=r,this.menubarService=b,Ze(()=>{let g=this.activeItemPath();L(g)?(this.bindOutsideClickListener(),this.bindResizeListener()):(this.unbindOutsideClickListener(),this.unbindResizeListener())})}onInit(){this.bindMatchMediaListener(),this.menubarService.autoHide=this.autoHide,this.menubarService.autoHideDelay=this.autoHideDelay,this.mouseLeaveSubscriber=this.menubarService.mouseLeft$.subscribe(()=>{this.hide()}),this.id=this.id||Xe("pn_id_")}startTemplate;endTemplate;itemTemplate;menuIconTemplate;submenuIconTemplate;templates;_startTemplate;_endTemplate;_itemTemplate;_menuIconTemplate;_submenuIconTemplate;onAfterContentInit(){this.templates?.forEach(e=>{switch(e.getType()){case"start":this._startTemplate=e.template;break;case"end":this._endTemplate=e.template;break;case"menuicon":this._menuIconTemplate=e.template;break;case"submenuicon":this._submenuIconTemplate=e.template;break;case"item":this._itemTemplate=e.template;break;default:this._itemTemplate=e.template;break}})}createProcessedItems(e,t=0,n={},o=""){let r=[];return e&&e.forEach((b,g)=>{let y=(o!==""?o+"_":"")+g,P={item:b,index:g,level:t,key:y,parent:n,parentKey:o};P.items=this.createProcessedItems(b.items,t+1,P,y),r.push(P)}),r}bindMatchMediaListener(){if(te(this.platformId)&&!this.matchMediaListener){let e=window.matchMedia(`(max-width: ${this.breakpoint})`);this.query=e,this.queryMatches=e.matches,this.matchMediaListener=()=>{this.queryMatches=e.matches,this.mobileActive=!1,this.cd.markForCheck()},e.addEventListener("change",this.matchMediaListener)}}unbindMatchMediaListener(){this.matchMediaListener&&(this.query.removeEventListener("change",this.matchMediaListener),this.matchMediaListener=null)}getItemProp(e,t){return e?de(e[t]):void 0}menuButtonClick(e){this.toggle(e)}menuButtonKeydown(e){(e.code==="Enter"||e.code==="Space")&&this.menuButtonClick(e)}onItemClick(e){let{originalEvent:t,processedItem:n}=e,o=this.isProcessedItemGroup(n),r=Q(n.parent);if(this.isSelected(n)){let{index:g,key:y,level:P,parentKey:ie,item:U}=n;this.activeItemPath.set(this.activeItemPath().filter(O=>y!==O.key&&y.startsWith(O.key))),this.focusedItemInfo.set({index:g,level:P,parentKey:ie,item:U}),this.dirty=!r,F(this.rootmenu?.el.nativeElement)}else if(o)this.onItemChange(e);else{let g=r?n:this.activeItemPath().find(y=>y.parentKey==="");this.hide(t),this.changeFocusedItemIndex(t,g?g.index:-1),this.mobileActive=!1,F(this.rootmenu?.el.nativeElement)}}onItemMouseEnter(e){le()?this.onItemChange({event:e,processedItem:e.processedItem,focus:this.autoDisplay},"hover"):this.dirty&&this.onItemChange(e,"hover")}onMouseLeave(e){let t=this.menubarService.autoHide,n=this.menubarService.autoHideDelay;t&&setTimeout(()=>{this.menubarService.mouseLeaves.next(!0)},n)}changeFocusedItemIndex(e,t){let n=this.findVisibleItem(t);if(this.focusedItemInfo().index!==t){let o=this.focusedItemInfo();this.focusedItemInfo.set(Te(Ce({},o),{item:n.item,index:t})),this.scrollInView()}}scrollInView(e=-1){let t=e!==-1?`${this.id}_${e}`:this.focusedItemId,n=j(this.rootmenu?.el.nativeElement,`li[id="${t}"]`);n&&n.scrollIntoView&&n.scrollIntoView({block:"nearest",inline:"nearest"})}onItemChange(e,t){let{processedItem:n,isFocus:o}=e;if(Q(n))return;let{index:r,key:b,level:g,parentKey:y,items:P,item:ie}=n,U=L(P),O=this.activeItemPath().filter(ve=>ve.parentKey!==y&&ve.parentKey!==b);U&&O.push(n),this.focusedItemInfo.set({index:r,level:g,parentKey:y,item:ie}),U&&(this.dirty=!0),o&&F(this.rootmenu?.el.nativeElement),!(t==="hover"&&this.queryMatches)&&this.activeItemPath.set(O)}toggle(e){this.mobileActive?(this.mobileActive=!1,fe.clear(this.rootmenu?.el.nativeElement),this.hide()):(this.mobileActive=!0,fe.set("menu",this.rootmenu?.el.nativeElement,this.config.zIndex.menu),setTimeout(()=>{this.show()},0)),this.bindOutsideClickListener(),e.preventDefault()}hide(e,t){this.mobileActive&&setTimeout(()=>{F(this.menubutton?.nativeElement)},0),this.activeItemPath.set([]),this.focusedItemInfo.set({index:-1,level:0,parentKey:"",item:null}),t&&F(this.rootmenu?.el.nativeElement),this.dirty=!1}show(){let e=this.findVisibleItem(this.findFirstFocusedItemIndex());this.focusedItemInfo.set({index:this.findFirstFocusedItemIndex(),level:0,parentKey:"",item:e?.item}),F(this.rootmenu?.el.nativeElement)}onMenuFocus(e){this.focused=!0;let t=this.findVisibleItem(this.findFirstFocusedItemIndex()),n=this.focusedItemInfo().index!==-1?this.focusedItemInfo():{index:this.findFirstFocusedItemIndex(),level:0,parentKey:"",item:t?.item};this.focusedItemInfo.set(n),this.onFocus.emit(e)}onMenuBlur(e){this.focused=!1,this.focusedItemInfo.set({index:-1,level:0,parentKey:"",item:null}),this.searchValue="",this.dirty=!1,this.onBlur.emit(e)}onKeyDown(e){let t=e.metaKey||e.ctrlKey;switch(e.code){case"ArrowDown":this.onArrowDownKey(e);break;case"ArrowUp":this.onArrowUpKey(e);break;case"ArrowLeft":this.onArrowLeftKey(e);break;case"ArrowRight":this.onArrowRightKey(e);break;case"Home":this.onHomeKey(e);break;case"End":this.onEndKey(e);break;case"Space":this.onSpaceKey(e);break;case"Enter":this.onEnterKey(e);break;case"Escape":this.onEscapeKey(e);break;case"Tab":this.onTabKey(e);break;case"PageDown":case"PageUp":case"Backspace":case"ShiftLeft":case"ShiftRight":break;default:!t&&Je(e.key)&&this.searchItems(e,e.key);break}}findVisibleItem(e){return L(this.visibleItems)?this.visibleItems[e]:null}findFirstFocusedItemIndex(){let e=this.findSelectedItemIndex();return e<0?this.findFirstItemIndex():e}findFirstItemIndex(){return this.visibleItems.findIndex(e=>this.isValidItem(e))}findSelectedItemIndex(){return this.visibleItems.findIndex(e=>this.isValidSelectedItem(e))}isProcessedItemGroup(e){return e&&L(e.items)}isSelected(e){return this.activeItemPath().some(t=>t.key===e.key)}isValidSelectedItem(e){return this.isValidItem(e)&&this.isSelected(e)}isValidItem(e){return!!e&&!this.isItemDisabled(e.item)&&!this.isItemSeparator(e.item)}isItemDisabled(e){return this.getItemProp(e,"disabled")}isItemSeparator(e){return this.getItemProp(e,"separator")}isItemMatched(e){return this.isValidItem(e)&&this.getProccessedItemLabel(e).toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase())}isProccessedItemGroup(e){return e&&L(e.items)}searchItems(e,t){this.searchValue=(this.searchValue||"")+t;let n=-1,o=!1;return this.focusedItemInfo().index!==-1?(n=this.visibleItems.slice(this.focusedItemInfo().index).findIndex(r=>this.isItemMatched(r)),n=n===-1?this.visibleItems.slice(0,this.focusedItemInfo().index).findIndex(r=>this.isItemMatched(r)):n+this.focusedItemInfo().index):n=this.visibleItems.findIndex(r=>this.isItemMatched(r)),n!==-1&&(o=!0),n===-1&&this.focusedItemInfo().index===-1&&(n=this.findFirstFocusedItemIndex()),n!==-1&&this.changeFocusedItemIndex(e,n),this.searchTimeout&&clearTimeout(this.searchTimeout),this.searchTimeout=setTimeout(()=>{this.searchValue="",this.searchTimeout=null},500),o}getProccessedItemLabel(e){return e?this.getItemLabel(e.item):void 0}getItemLabel(e){return this.getItemProp(e,"label")}onArrowDownKey(e){let t=this.visibleItems[this.focusedItemInfo().index];if(t?Q(t.parent):null)this.isProccessedItemGroup(t)&&(this.onItemChange({originalEvent:e,processedItem:t}),this.focusedItemInfo.set({index:-1,parentKey:t.key,item:t.item}),this.onArrowRightKey(e));else{let o=this.focusedItemInfo().index!==-1?this.findNextItemIndex(this.focusedItemInfo().index):this.findFirstFocusedItemIndex();this.changeFocusedItemIndex(e,o),e.preventDefault()}}onArrowRightKey(e){let t=this.visibleItems[this.focusedItemInfo().index];if(t?this.activeItemPath().find(o=>o.key===t.parentKey):null)this.isProccessedItemGroup(t)&&(this.onItemChange({originalEvent:e,processedItem:t}),this.focusedItemInfo.set({index:-1,parentKey:t.key,item:t.item}),this.onArrowDownKey(e));else{let o=this.focusedItemInfo().index!==-1?this.findNextItemIndex(this.focusedItemInfo().index):this.findFirstFocusedItemIndex();this.changeFocusedItemIndex(e,o),e.preventDefault()}}onArrowUpKey(e){let t=this.visibleItems[this.focusedItemInfo().index];if(Q(t.parent)){if(this.isProccessedItemGroup(t)){this.onItemChange({originalEvent:e,processedItem:t}),this.focusedItemInfo.set({index:-1,parentKey:t.key,item:t.item});let r=this.findLastItemIndex();this.changeFocusedItemIndex(e,r)}}else{let o=this.activeItemPath().find(r=>r.key===t.parentKey);if(this.focusedItemInfo().index===0){this.focusedItemInfo.set({index:-1,parentKey:o?o.parentKey:"",item:t.item}),this.searchValue="",this.onArrowLeftKey(e);let r=this.activeItemPath().filter(b=>b.parentKey!==this.focusedItemInfo().parentKey);this.activeItemPath.set(r)}else{let r=this.focusedItemInfo().index!==-1?this.findPrevItemIndex(this.focusedItemInfo().index):this.findLastFocusedItemIndex();this.changeFocusedItemIndex(e,r)}}e.preventDefault()}onArrowLeftKey(e){let t=this.visibleItems[this.focusedItemInfo().index],n=t?this.activeItemPath().find(o=>o.key===t.parentKey):null;if(n){this.onItemChange({originalEvent:e,processedItem:n});let o=this.activeItemPath().filter(r=>r.parentKey!==this.focusedItemInfo().parentKey);this.activeItemPath.set(o),e.preventDefault()}else{let o=this.focusedItemInfo().index!==-1?this.findPrevItemIndex(this.focusedItemInfo().index):this.findLastFocusedItemIndex();this.changeFocusedItemIndex(e,o),e.preventDefault()}}onHomeKey(e){this.changeFocusedItemIndex(e,this.findFirstItemIndex()),e.preventDefault()}onEndKey(e){this.changeFocusedItemIndex(e,this.findLastItemIndex()),e.preventDefault()}onSpaceKey(e){this.onEnterKey(e)}onEscapeKey(e){this.hide(e,!0),this.focusedItemInfo().index=this.findFirstFocusedItemIndex(),e.preventDefault()}onTabKey(e){if(this.focusedItemInfo().index!==-1){let t=this.visibleItems[this.focusedItemInfo().index];!this.isProccessedItemGroup(t)&&this.onItemChange({originalEvent:e,processedItem:t})}this.hide()}onEnterKey(e){if(this.focusedItemInfo().index!==-1){let t=j(this.rootmenu?.el.nativeElement,`li[id="${`${this.focusedItemId}`}"]`),n=t&&(j(t,'[data-pc-section="itemlink"]')||j(t,"a,button"));n?n.click():t&&t.click()}e.preventDefault()}findLastFocusedItemIndex(){let e=this.findSelectedItemIndex();return e<0?this.findLastItemIndex():e}findLastItemIndex(){return pe(this.visibleItems,e=>this.isValidItem(e))}findPrevItemIndex(e){let t=e>0?pe(this.visibleItems.slice(0,e),n=>this.isValidItem(n)):-1;return t>-1?t:e}findNextItemIndex(e){let t=e<this.visibleItems.length-1?this.visibleItems.slice(e+1).findIndex(n=>this.isValidItem(n)):-1;return t>-1?t+e+1:e}bindResizeListener(){te(this.platformId)&&(this.resizeListener||(this.resizeListener=this.renderer.listen(this.document.defaultView,"resize",e=>{le()||this.hide(e,!0),this.mobileActive=!1})))}bindOutsideClickListener(){te(this.platformId)&&(this.outsideClickListener||(this.outsideClickListener=this.renderer.listen(this.document,"click",e=>{let t=this.rootmenu?.el.nativeElement!==e.target&&!this.rootmenu?.el.nativeElement?.contains(e.target),n=this.mobileActive&&this.menubutton?.nativeElement!==e.target&&!this.menubutton?.nativeElement?.contains(e.target);t&&(n?this.mobileActive=!1:this.hide())})))}unbindOutsideClickListener(){this.outsideClickListener&&(this.outsideClickListener(),this.outsideClickListener=null)}unbindResizeListener(){this.resizeListener&&(this.resizeListener(),this.resizeListener=null)}onDestroy(){this.mouseLeaveSubscriber?.unsubscribe(),this.unbindOutsideClickListener(),this.unbindResizeListener(),this.unbindMatchMediaListener()}static \u0275fac=function(t){return new(t||i)(v(Ee),v(De),v(Be),v(Ae),v(qe),v(xe))};static \u0275cmp=w({type:i,selectors:[["p-menubar"]],contentQueries:function(t,n,o){if(t&1&&(D(o,Xt,4),D(o,Yt,4),D(o,en,4),D(o,tn,4),D(o,nn,4),D(o,ne,4)),t&2){let r;C(r=T())&&(n.startTemplate=r.first),C(r=T())&&(n.endTemplate=r.first),C(r=T())&&(n.itemTemplate=r.first),C(r=T())&&(n.menuIconTemplate=r.first),C(r=T())&&(n.submenuIconTemplate=r.first),C(r=T())&&(n.templates=r)}},viewQuery:function(t,n){if(t&1&&(se(on,5),se(rn,5)),t&2){let o;C(o=T())&&(n.menubutton=o.first),C(o=T())&&(n.rootmenu=o.first)}},hostVars:2,hostBindings:function(t,n){t&2&&d(n.cn(n.cx("root"),n.styleClass))},inputs:{model:"model",styleClass:"styleClass",autoZIndex:[2,"autoZIndex","autoZIndex",S],baseZIndex:[2,"baseZIndex","baseZIndex",Z],autoDisplay:[2,"autoDisplay","autoDisplay",S],autoHide:[2,"autoHide","autoHide",S],breakpoint:"breakpoint",autoHideDelay:[2,"autoHideDelay","autoHideDelay",Z],id:"id",ariaLabel:"ariaLabel",ariaLabelledBy:"ariaLabelledBy"},outputs:{onFocus:"onFocus",onBlur:"onBlur"},features:[ze([xe,ge,{provide:bt,useExisting:i},{provide:et,useExisting:i}]),Ke([K]),H],ngContentSelectors:an,decls:7,vars:19,consts:[["rootmenu",""],["legacy",""],["menubutton",""],[3,"class","pBind",4,"ngIf"],["tabindex","0","role","button",3,"class","pBind","click","keydown",4,"ngIf"],["pMenubarSub","","tabindex","0",3,"itemClick","focus","blur","keydown","itemMouseEnter","mouseleave","items","itemTemplate","menuId","root","baseZIndex","autoZIndex","mobileActive","autoDisplay","focusedItemId","submenuiconTemplate","activeItemPath","pt","pBind"],[3,"class","pBind",4,"ngIf","ngIfElse"],[3,"pBind"],[4,"ngTemplateOutlet"],["tabindex","0","role","button",3,"click","keydown","pBind"],["data-p-icon","bars",3,"pBind",4,"ngIf"],["data-p-icon","bars",3,"pBind"]],template:function(t,n){if(t&1){let o=$();He(),l(0,mn,2,4,"div",3)(1,pn,4,9,"a",4),p(2,"ul",5,0),N("itemClick",function(b){return I(o),f(n.onItemClick(b))})("focus",function(b){return I(o),f(n.onMenuFocus(b))})("blur",function(b){return I(o),f(n.onMenuBlur(b))})("keydown",function(b){return I(o),f(n.onKeyDown(b))})("itemMouseEnter",function(b){return I(o),f(n.onItemMouseEnter(b))})("mouseleave",function(b){return I(o),f(n.onMouseLeave(b))}),c(),l(4,bn,2,4,"div",6)(5,_n,2,2,"ng-template",null,1,ee)}if(t&2){let o=J(6);a("ngIf",n.startTemplate||n._startTemplate),u(),a("ngIf",n.model&&n.model.length>0),u(),a("items",n.processedItems)("itemTemplate",n.itemTemplate)("menuId",n.id)("root",!0)("baseZIndex",n.baseZIndex)("autoZIndex",n.autoZIndex)("mobileActive",n.mobileActive)("autoDisplay",n.autoDisplay)("focusedItemId",n.focused?n.focusedItemId:void 0)("submenuiconTemplate",n.submenuIconTemplate||n._submenuIconTemplate)("activeItemPath",n.activeItemPath())("pt",n.pt())("pBind",n.ptm("rootList")),x("aria-label",n.ariaLabel)("aria-labelledby",n.ariaLabelledBy),u(2),a("ngIf",n.endTemplate||n._endTemplate)("ngIfElse",o)}},dependencies:[q,me,ue,ce,hn,he,K,pt,Ie,G,_e],encapsulation:2,changeDetection:0})}return i})(),It=(()=>{class i{static \u0275fac=function(t){return new(t||i)};static \u0275mod=Ve({type:i});static \u0275inj=Pe({imports:[ye,G,G]})}return i})();var xn=()=>({"min-width":"50rem"});function yn(i,m){i&1&&(p(0,"span",9),h(1,"SEMOP ERP"),c())}function vn(i,m){i&1&&(p(0,"tr")(1,"th"),h(2,"\u0627\u0644\u0631\u0642\u0645"),c(),p(3,"th"),h(4,"\u0627\u0644\u0627\u0633\u0645"),c(),p(5,"th"),h(6,"\u0627\u0644\u0648\u0635\u0641"),c(),p(7,"th"),h(8,"\u0627\u0644\u0625\u062C\u0631\u0627\u0621\u0627\u062A"),c()())}function Cn(i,m){if(i&1&&(p(0,"tr")(1,"td"),h(2),c(),p(3,"td"),h(4),c(),p(5,"td"),h(6),c(),p(7,"td"),_(8,"p-button",10)(9,"p-button",11),c()()),i&2){let e=m.$implicit;u(2),V(e.id),u(2),V(e.name),u(2),V(e.description),u(2),a("text",!0),u(),a("text",!0)}}var ft=class i{constructor(m){this.router=m}menuItems=[{label:"\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629",icon:"pi pi-home",command:()=>this.router.navigate(["/dashboard"])}];items=[{id:1,name:"\u0645\u062F\u064A\u0631 \u0627\u0644\u0646\u0638\u0627\u0645",description:"\u0635\u0644\u0627\u062D\u064A\u0627\u062A \u0643\u0627\u0645\u0644\u0629"},{id:2,name:"\u0645\u062D\u0627\u0633\u0628",description:"\u0625\u062F\u0627\u0631\u0629 \u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A"}];static \u0275fac=function(e){return new(e||i)(v(Ge))};static \u0275cmp=w({type:i,selectors:[["app-reports"]],decls:10,vars:4,consts:[[3,"model"],["pTemplate","start"],[1,"p-4"],[1,"flex","justify-content-between","align-items-center","mb-4"],[1,"text-3xl","font-bold"],["label","\u0625\u0636\u0627\u0641\u0629 reports","icon","pi pi-plus","severity","success"],[3,"value","tableStyle"],["pTemplate","header"],["pTemplate","body"],[1,"text-xl","font-bold"],["icon","pi pi-pencil","severity","info",1,"mr-2",3,"text"],["icon","pi pi-trash","severity","danger",3,"text"]],template:function(e,t){e&1&&(p(0,"p-menubar",0),l(1,yn,2,0,"ng-template",1),c(),p(2,"div",2)(3,"div",3)(4,"h1",4),h(5,"\u0625\u062F\u0627\u0631\u0629 \u0627\u0644reports"),c(),_(6,"p-button",5),c(),p(7,"p-table",6),l(8,vn,9,0,"ng-template",7)(9,Cn,10,5,"ng-template",8),c()()),e&2&&(a("model",t.menuItems),u(7),a("value",t.items)("tableStyle",X(3,xn)))},dependencies:[q,It,ye,ne,ct,ut,st,at],encapsulation:2})};export{ft as ReportsComponent};
