import{a as Kt}from"./chunk-LV5ZAQ3Q.js";import{a as te}from"./chunk-XXH5K42U.js";import{b as Jt,d as Yt}from"./chunk-DIZVUWJX.js";import{$ as w,$b as W,Ab as B,Bb as lt,Cb as bt,Cd as Gt,Db as Ot,Dd as Zt,Eb as Ct,Gb as g,Hb as at,Hc as jt,Ib as ct,Ic as Wt,Jb as P,Jc as vt,Jd as Ut,Kb as pt,Kc as Qt,Lb as z,Lc as It,Mb as E,Nc as Q,Pa as p,Pb as ut,Qb as Pt,Rc as Et,Sb as yt,Tb as v,Td as wt,Ua as H,Ud as L,V as Bt,Va as Lt,W as R,X as nt,Xd as $,Yd as q,Z as A,Za as Nt,Zd as dt,a as _t,ac as Rt,b as kt,bc as xt,cb as b,cc as tt,db as rt,ea as ot,ee as x,fa as st,fb as C,fe as ht,ga as k,gb as j,hb as y,hd as $t,je as N,kc as mt,ke as Xt,md as et,na as Dt,nb as K,oc as At,ra as f,rc as zt,sb as a,sd as it,tb as X,td as Vt,ub as J,ud as qt,vb as Y,wb as St,wc as ft,xb as Tt,xc as Ht,yb as F,zb as M}from"./chunk-RDKUJFH5.js";var fe=["data-p-icon","chevron-down"],mi=(()=>{class e extends N{static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["","data-p-icon","chevron-down"]],features:[C],attrs:fe,decls:1,vars:0,consts:[["d","M7.01744 10.398C6.91269 10.3985 6.8089 10.378 6.71215 10.3379C6.61541 10.2977 6.52766 10.2386 6.45405 10.1641L1.13907 4.84913C1.03306 4.69404 0.985221 4.5065 1.00399 4.31958C1.02276 4.13266 1.10693 3.95838 1.24166 3.82747C1.37639 3.69655 1.55301 3.61742 1.74039 3.60402C1.92777 3.59062 2.11386 3.64382 2.26584 3.75424L7.01744 8.47394L11.769 3.75424C11.9189 3.65709 12.097 3.61306 12.2748 3.62921C12.4527 3.64535 12.6199 3.72073 12.7498 3.84328C12.8797 3.96582 12.9647 4.12842 12.9912 4.30502C13.0177 4.48162 12.9841 4.662 12.8958 4.81724L7.58083 10.1322C7.50996 10.2125 7.42344 10.2775 7.32656 10.3232C7.22968 10.3689 7.12449 10.3944 7.01744 10.398Z","fill","currentColor"]],template:function(i,n){i&1&&(k(),F(0,"path",0))},encapsulation:2})}return e})();var ge=["data-p-icon","chevron-left"],_i=(()=>{class e extends N{static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["","data-p-icon","chevron-left"]],features:[C],attrs:ge,decls:1,vars:0,consts:[["d","M9.61296 13C9.50997 13.0005 9.40792 12.9804 9.3128 12.9409C9.21767 12.9014 9.13139 12.8433 9.05902 12.7701L3.83313 7.54416C3.68634 7.39718 3.60388 7.19795 3.60388 6.99022C3.60388 6.78249 3.68634 6.58325 3.83313 6.43628L9.05902 1.21039C9.20762 1.07192 9.40416 0.996539 9.60724 1.00012C9.81032 1.00371 10.0041 1.08597 10.1477 1.22959C10.2913 1.37322 10.3736 1.56698 10.3772 1.77005C10.3808 1.97313 10.3054 2.16968 10.1669 2.31827L5.49496 6.99022L10.1669 11.6622C10.3137 11.8091 10.3962 12.0084 10.3962 12.2161C10.3962 12.4238 10.3137 12.6231 10.1669 12.7701C10.0945 12.8433 10.0083 12.9014 9.91313 12.9409C9.81801 12.9804 9.71596 13.0005 9.61296 13Z","fill","currentColor"]],template:function(i,n){i&1&&(k(),F(0,"path",0))},encapsulation:2})}return e})();var _e=["data-p-icon","chevron-right"],yi=(()=>{class e extends N{static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["","data-p-icon","chevron-right"]],features:[C],attrs:_e,decls:1,vars:0,consts:[["d","M4.38708 13C4.28408 13.0005 4.18203 12.9804 4.08691 12.9409C3.99178 12.9014 3.9055 12.8433 3.83313 12.7701C3.68634 12.6231 3.60388 12.4238 3.60388 12.2161C3.60388 12.0084 3.68634 11.8091 3.83313 11.6622L8.50507 6.99022L3.83313 2.31827C3.69467 2.16968 3.61928 1.97313 3.62287 1.77005C3.62645 1.56698 3.70872 1.37322 3.85234 1.22959C3.99596 1.08597 4.18972 1.00371 4.3928 1.00012C4.59588 0.996539 4.79242 1.07192 4.94102 1.21039L10.1669 6.43628C10.3137 6.58325 10.3962 6.78249 10.3962 6.99022C10.3962 7.19795 10.3137 7.39718 10.1669 7.54416L4.94102 12.7701C4.86865 12.8433 4.78237 12.9014 4.68724 12.9409C4.59212 12.9804 4.49007 13.0005 4.38708 13Z","fill","currentColor"]],template:function(i,n){i&1&&(k(),F(0,"path",0))},encapsulation:2})}return e})();var be=["data-p-icon","search"],wi=(()=>{class e extends N{pathId;onInit(){this.pathId="url(#"+Ut()+")"}static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["","data-p-icon","search"]],features:[C],attrs:be,decls:5,vars:2,consts:[["fill-rule","evenodd","clip-rule","evenodd","d","M2.67602 11.0265C3.6661 11.688 4.83011 12.0411 6.02086 12.0411C6.81149 12.0411 7.59438 11.8854 8.32483 11.5828C8.87005 11.357 9.37808 11.0526 9.83317 10.6803L12.9769 13.8241C13.0323 13.8801 13.0983 13.9245 13.171 13.9548C13.2438 13.985 13.3219 14.0003 13.4007 14C13.4795 14.0003 13.5575 13.985 13.6303 13.9548C13.7031 13.9245 13.7691 13.8801 13.8244 13.8241C13.9367 13.7116 13.9998 13.5592 13.9998 13.4003C13.9998 13.2414 13.9367 13.089 13.8244 12.9765L10.6807 9.8328C11.053 9.37773 11.3573 8.86972 11.5831 8.32452C11.8857 7.59408 12.0414 6.81119 12.0414 6.02056C12.0414 4.8298 11.6883 3.66579 11.0268 2.67572C10.3652 1.68564 9.42494 0.913972 8.32483 0.45829C7.22472 0.00260857 6.01418 -0.116618 4.84631 0.115686C3.67844 0.34799 2.60568 0.921393 1.76369 1.76338C0.921698 2.60537 0.348296 3.67813 0.115991 4.84601C-0.116313 6.01388 0.00291375 7.22441 0.458595 8.32452C0.914277 9.42464 1.68595 10.3649 2.67602 11.0265ZM3.35565 2.0158C4.14456 1.48867 5.07206 1.20731 6.02086 1.20731C7.29317 1.20731 8.51338 1.71274 9.41304 2.6124C10.3127 3.51206 10.8181 4.73226 10.8181 6.00457C10.8181 6.95337 10.5368 7.88088 10.0096 8.66978C9.48251 9.45868 8.73328 10.0736 7.85669 10.4367C6.98011 10.7997 6.01554 10.8947 5.08496 10.7096C4.15439 10.5245 3.2996 10.0676 2.62869 9.39674C1.95778 8.72583 1.50089 7.87104 1.31579 6.94046C1.13068 6.00989 1.22568 5.04532 1.58878 4.16874C1.95187 3.29215 2.56675 2.54292 3.35565 2.0158Z","fill","currentColor"],[3,"id"],["width","14","height","14","fill","white"]],template:function(i,n){i&1&&(k(),St(0,"g"),F(1,"path",0),Tt(),St(2,"defs")(3,"clipPath",1),F(4,"rect",2),Tt()()),i&2&&(K("clip-path",n.pathId),p(3),Ot("id",n.pathId))},encapsulation:2})}return e})();var Ce=["data-p-icon","minus"],ee=(()=>{class e extends N{static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["","data-p-icon","minus"]],features:[C],attrs:Ce,decls:1,vars:0,consts:[["d","M13.2222 7.77778H0.777778C0.571498 7.77778 0.373667 7.69584 0.227806 7.54998C0.0819442 7.40412 0 7.20629 0 7.00001C0 6.79373 0.0819442 6.5959 0.227806 6.45003C0.373667 6.30417 0.571498 6.22223 0.777778 6.22223H13.2222C13.4285 6.22223 13.6263 6.30417 13.7722 6.45003C13.9181 6.5959 14 6.79373 14 7.00001C14 7.20629 13.9181 7.40412 13.7722 7.54998C13.6263 7.69584 13.4285 7.77778 13.2222 7.77778Z","fill","currentColor"]],template:function(i,n){i&1&&(k(),F(0,"path",0))},encapsulation:2})}return e})();var ie=`
    .p-checkbox {
        position: relative;
        display: inline-flex;
        user-select: none;
        vertical-align: bottom;
        width: dt('checkbox.width');
        height: dt('checkbox.height');
    }

    .p-checkbox-input {
        cursor: pointer;
        appearance: none;
        position: absolute;
        inset-block-start: 0;
        inset-inline-start: 0;
        width: 100%;
        height: 100%;
        padding: 0;
        margin: 0;
        opacity: 0;
        z-index: 1;
        outline: 0 none;
        border: 1px solid transparent;
        border-radius: dt('checkbox.border.radius');
    }

    .p-checkbox-box {
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: dt('checkbox.border.radius');
        border: 1px solid dt('checkbox.border.color');
        background: dt('checkbox.background');
        width: dt('checkbox.width');
        height: dt('checkbox.height');
        transition:
            background dt('checkbox.transition.duration'),
            color dt('checkbox.transition.duration'),
            border-color dt('checkbox.transition.duration'),
            box-shadow dt('checkbox.transition.duration'),
            outline-color dt('checkbox.transition.duration');
        outline-color: transparent;
        box-shadow: dt('checkbox.shadow');
    }

    .p-checkbox-icon {
        transition-duration: dt('checkbox.transition.duration');
        color: dt('checkbox.icon.color');
        font-size: dt('checkbox.icon.size');
        width: dt('checkbox.icon.size');
        height: dt('checkbox.icon.size');
    }

    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        border-color: dt('checkbox.hover.border.color');
    }

    .p-checkbox-checked .p-checkbox-box {
        border-color: dt('checkbox.checked.border.color');
        background: dt('checkbox.checked.background');
    }

    .p-checkbox-checked .p-checkbox-icon {
        color: dt('checkbox.icon.checked.color');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        background: dt('checkbox.checked.hover.background');
        border-color: dt('checkbox.checked.hover.border.color');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-icon {
        color: dt('checkbox.icon.checked.hover.color');
    }

    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
        border-color: dt('checkbox.focus.border.color');
        box-shadow: dt('checkbox.focus.ring.shadow');
        outline: dt('checkbox.focus.ring.width') dt('checkbox.focus.ring.style') dt('checkbox.focus.ring.color');
        outline-offset: dt('checkbox.focus.ring.offset');
    }

    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {
        border-color: dt('checkbox.checked.focus.border.color');
    }

    .p-checkbox.p-invalid > .p-checkbox-box {
        border-color: dt('checkbox.invalid.border.color');
    }

    .p-checkbox.p-variant-filled .p-checkbox-box {
        background: dt('checkbox.filled.background');
    }

    .p-checkbox-checked.p-variant-filled .p-checkbox-box {
        background: dt('checkbox.checked.background');
    }

    .p-checkbox-checked.p-variant-filled:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {
        background: dt('checkbox.checked.hover.background');
    }

    .p-checkbox.p-disabled {
        opacity: 1;
    }

    .p-checkbox.p-disabled .p-checkbox-box {
        background: dt('checkbox.disabled.background');
        border-color: dt('checkbox.checked.disabled.border.color');
    }

    .p-checkbox.p-disabled .p-checkbox-box .p-checkbox-icon {
        color: dt('checkbox.icon.disabled.color');
    }

    .p-checkbox-sm,
    .p-checkbox-sm .p-checkbox-box {
        width: dt('checkbox.sm.width');
        height: dt('checkbox.sm.height');
    }

    .p-checkbox-sm .p-checkbox-icon {
        font-size: dt('checkbox.icon.sm.size');
        width: dt('checkbox.icon.sm.size');
        height: dt('checkbox.icon.sm.size');
    }

    .p-checkbox-lg,
    .p-checkbox-lg .p-checkbox-box {
        width: dt('checkbox.lg.width');
        height: dt('checkbox.lg.height');
    }

    .p-checkbox-lg .p-checkbox-icon {
        font-size: dt('checkbox.icon.lg.size');
        width: dt('checkbox.icon.lg.size');
        height: dt('checkbox.icon.lg.size');
    }
`;var xe=["icon"],ve=["input"],Ie=(e,l)=>({checked:e,class:l});function we(e,l){if(e&1&&Y(0,"span",8),e&2){let t=g(3);v(t.cx("icon")),a("ngClass",t.checkboxIcon)("pBind",t.ptm("icon"))}}function ke(e,l){if(e&1&&(k(),Y(0,"svg",9)),e&2){let t=g(3);v(t.cx("icon")),a("pBind",t.ptm("icon"))}}function Se(e,l){if(e&1&&(M(0),y(1,we,1,4,"span",6)(2,ke,1,3,"svg",7),B()),e&2){let t=g(2);p(),a("ngIf",t.checkboxIcon),p(),a("ngIf",!t.checkboxIcon)}}function Te(e,l){if(e&1&&(k(),Y(0,"svg",10)),e&2){let t=g(2);v(t.cx("icon")),a("pBind",t.ptm("icon"))}}function ze(e,l){if(e&1&&(M(0),y(1,Se,3,2,"ng-container",3)(2,Te,1,3,"svg",5),B()),e&2){let t=g();p(),a("ngIf",t.checked),p(),a("ngIf",t._indeterminate())}}function Ee(e,l){}function Ve(e,l){e&1&&y(0,Ee,0,0,"ng-template")}var Fe=`
    ${ie}

    /* For PrimeNG */
    p-checkBox.ng-invalid.ng-dirty .p-checkbox-box,
    p-check-box.ng-invalid.ng-dirty .p-checkbox-box,
    p-checkbox.ng-invalid.ng-dirty .p-checkbox-box {
        border-color: dt('checkbox.invalid.border.color');
    }
`,Me={root:({instance:e})=>["p-checkbox p-component",{"p-checkbox-checked p-highlight":e.checked,"p-disabled":e.$disabled(),"p-invalid":e.invalid(),"p-variant-filled":e.$variant()==="filled","p-checkbox-sm p-inputfield-sm":e.size()==="small","p-checkbox-lg p-inputfield-lg":e.size()==="large"}],box:"p-checkbox-box",input:"p-checkbox-input",icon:"p-checkbox-icon"},ne=(()=>{class e extends ${name="checkbox";style=Fe;classes=Me;static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275prov=R({token:e,factory:e.\u0275fac})}return e})();var oe=new A("CHECKBOX_INSTANCE"),Be={provide:Jt,useExisting:Bt(()=>se),multi:!0},se=(()=>{class e extends te{hostName="";value;binary;ariaLabelledBy;ariaLabel;tabindex;inputId;inputStyle;styleClass;inputClass;indeterminate=!1;formControl;checkboxIcon;readonly;autofocus;trueValue=!0;falseValue=!1;variant=zt();size=zt();onChange=new H;onFocus=new H;onBlur=new H;inputViewChild;get checked(){return this._indeterminate()?!1:this.binary?this.modelValue()===this.trueValue:Zt(this.value,this.modelValue())}_indeterminate=Dt(void 0);checkboxIconTemplate;templates;_checkboxIconTemplate;focused=!1;_componentStyle=w(ne);bindDirectiveInstance=w(x,{self:!0});$pcCheckbox=w(oe,{optional:!0,skipSelf:!0})??void 0;$variant=At(()=>this.variant()||this.config.inputStyle()||this.config.inputVariant());onAfterContentInit(){this.templates?.forEach(t=>{switch(t.getType()){case"icon":this._checkboxIconTemplate=t.template;break;case"checkboxicon":this._checkboxIconTemplate=t.template;break}})}onChanges(t){t.indeterminate&&this._indeterminate.set(t.indeterminate.currentValue)}onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}updateModel(t){let i,n=this.injector.get(Yt,null,{optional:!0,self:!0}),o=n&&!this.formControl?n.value:this.modelValue();this.binary?(i=this._indeterminate()?this.trueValue:this.checked?this.falseValue:this.trueValue,this.writeModelValue(i),this.onModelChange(i)):(this.checked||this._indeterminate()?i=o.filter(s=>!Gt(s,this.value)):i=o?[...o,this.value]:[this.value],this.onModelChange(i),this.writeModelValue(i),this.formControl&&this.formControl.setValue(i)),this._indeterminate()&&this._indeterminate.set(!1),this.onChange.emit({checked:i,originalEvent:t})}handleChange(t){this.readonly||this.updateModel(t)}onInputFocus(t){this.focused=!0,this.onFocus.emit(t)}onInputBlur(t){this.focused=!1,this.onBlur.emit(t),this.onModelTouched()}focus(){this.inputViewChild?.nativeElement.focus()}writeControlValue(t,i){i(t),this.cd.markForCheck()}static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["p-checkbox"],["p-checkBox"],["p-check-box"]],contentQueries:function(i,n,o){if(i&1&&(P(o,xe,4),P(o,wt,4)),i&2){let s;z(s=E())&&(n.checkboxIconTemplate=s.first),z(s=E())&&(n.templates=s)}},viewQuery:function(i,n){if(i&1&&pt(ve,5),i&2){let o;z(o=E())&&(n.inputViewChild=o.first)}},hostVars:5,hostBindings:function(i,n){i&2&&(K("data-p-highlight",n.checked)("data-p-checked",n.checked)("data-p-disabled",n.$disabled()),v(n.cn(n.cx("root"),n.styleClass)))},inputs:{hostName:"hostName",value:"value",binary:[2,"binary","binary",ft],ariaLabelledBy:"ariaLabelledBy",ariaLabel:"ariaLabel",tabindex:[2,"tabindex","tabindex",Ht],inputId:"inputId",inputStyle:"inputStyle",styleClass:"styleClass",inputClass:"inputClass",indeterminate:[2,"indeterminate","indeterminate",ft],formControl:"formControl",checkboxIcon:"checkboxIcon",readonly:[2,"readonly","readonly",ft],autofocus:[2,"autofocus","autofocus",ft],trueValue:"trueValue",falseValue:"falseValue",variant:[1,"variant"],size:[1,"size"]},outputs:{onChange:"onChange",onFocus:"onFocus",onBlur:"onBlur"},features:[W([Be,ne,{provide:oe,useExisting:e},{provide:q,useExisting:e}]),j([x]),C],decls:5,vars:24,consts:[["input",""],["type","checkbox",3,"focus","blur","change","checked","pBind"],[3,"pBind"],[4,"ngIf"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],["data-p-icon","minus",3,"class","pBind",4,"ngIf"],[3,"class","ngClass","pBind",4,"ngIf"],["data-p-icon","check",3,"class","pBind",4,"ngIf"],[3,"ngClass","pBind"],["data-p-icon","check",3,"pBind"],["data-p-icon","minus",3,"pBind"]],template:function(i,n){if(i&1){let o=bt();X(0,"input",1,0),Ct("focus",function(r){return ot(o),st(n.onInputFocus(r))})("blur",function(r){return ot(o),st(n.onInputBlur(r))})("change",function(r){return ot(o),st(n.handleChange(r))}),J(),X(2,"div",2),y(3,ze,3,2,"ng-container",3)(4,Ve,1,0,null,4),J()}i&2&&(yt(n.inputStyle),v(n.cn(n.cx("input"),n.inputClass)),a("checked",n.checked)("pBind",n.ptm("input")),K("id",n.inputId)("value",n.value)("name",n.name())("tabindex",n.tabindex)("required",n.required()?"":void 0)("readonly",n.readonly?"":void 0)("disabled",n.$disabled()?"":void 0)("aria-labelledby",n.ariaLabelledBy)("aria-label",n.ariaLabel),p(2),v(n.cx("box")),a("pBind",n.ptm("box")),p(),a("ngIf",!n.checkboxIconTemplate&&!n._checkboxIconTemplate),p(),a("ngTemplateOutlet",n.checkboxIconTemplate||n._checkboxIconTemplate)("ngTemplateOutletContext",tt(21,Ie,n.checked,n.cx("icon"))))},dependencies:[Q,jt,vt,It,L,Kt,ee,ht,x],encapsulation:2,changeDetection:0})}return e})(),Xi=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275mod=rt({type:e});static \u0275inj=nt({imports:[se,L,L]})}return e})();var re=`
    .p-iconfield {
        position: relative;
        display: block;
    }

    .p-inputicon {
        position: absolute;
        top: 50%;
        margin-top: calc(-1 * (dt('icon.size') / 2));
        color: dt('iconfield.icon.color');
        line-height: 1;
        z-index: 1;
    }

    .p-iconfield .p-inputicon:first-child {
        inset-inline-start: dt('form.field.padding.x');
    }

    .p-iconfield .p-inputicon:last-child {
        inset-inline-end: dt('form.field.padding.x');
    }

    .p-iconfield .p-inputtext:not(:first-child),
    .p-iconfield .p-inputwrapper:not(:first-child) .p-inputtext {
        padding-inline-start: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-iconfield .p-inputtext:not(:last-child) {
        padding-inline-end: calc((dt('form.field.padding.x') * 2) + dt('icon.size'));
    }

    .p-iconfield:has(.p-inputfield-sm) .p-inputicon {
        font-size: dt('form.field.sm.font.size');
        width: dt('form.field.sm.font.size');
        height: dt('form.field.sm.font.size');
        margin-top: calc(-1 * (dt('form.field.sm.font.size') / 2));
    }

    .p-iconfield:has(.p-inputfield-lg) .p-inputicon {
        font-size: dt('form.field.lg.font.size');
        width: dt('form.field.lg.font.size');
        height: dt('form.field.lg.font.size');
        margin-top: calc(-1 * (dt('form.field.lg.font.size') / 2));
    }
`;var De=["*"],Le={root:({instance:e})=>["p-iconfield",{"p-iconfield-left":e.iconPosition=="left","p-iconfield-right":e.iconPosition=="right"}]},le=(()=>{class e extends ${name="iconfield";style=re;classes=Le;static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275prov=R({token:e,factory:e.\u0275fac})}return e})();var ae=new A("ICONFIELD_INSTANCE"),mn=(()=>{class e extends dt{hostName="";_componentStyle=w(le);$pcIconField=w(ae,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=w(x,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}iconPosition="left";styleClass;static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["p-iconfield"],["p-iconField"],["p-icon-field"]],hostVars:2,hostBindings:function(i,n){i&2&&v(n.cn(n.cx("root"),n.styleClass))},inputs:{hostName:"hostName",iconPosition:"iconPosition",styleClass:"styleClass"},features:[W([le,{provide:ae,useExisting:e},{provide:q,useExisting:e}]),j([x]),C],ngContentSelectors:De,decls:1,vars:0,template:function(i,n){i&1&&(at(),ct(0))},dependencies:[Q,ht],encapsulation:2,changeDetection:0})}return e})();var Ne=["*"],Oe={root:"p-inputicon"},ce=(()=>{class e extends ${name="inputicon";classes=Oe;static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275prov=R({token:e,factory:e.\u0275fac})}return e})(),de=new A("INPUTICON_INSTANCE"),zn=(()=>{class e extends dt{hostName="";styleClass;_componentStyle=w(ce);$pcInputIcon=w(de,{optional:!0,skipSelf:!0})??void 0;bindDirectiveInstance=w(x,{self:!0});onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptms(["host","root"]))}static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275cmp=b({type:e,selectors:[["p-inputicon"],["p-inputIcon"]],hostVars:2,hostBindings:function(i,n){i&2&&v(n.cn(n.cx("root"),n.styleClass))},inputs:{hostName:"hostName",styleClass:"styleClass"},features:[W([ce,{provide:de,useExisting:e},{provide:q,useExisting:e}]),j([x]),C],ngContentSelectors:Ne,decls:1,vars:0,template:function(i,n){i&1&&(at(),ct(0))},dependencies:[Q,L,ht],encapsulation:2,changeDetection:0})}return e})();var he=["content"],Pe=["item"],Re=["loader"],Ae=["loadericon"],He=["element"],je=["*"],Mt=(e,l)=>({$implicit:e,options:l}),We=e=>({numCols:e}),me=e=>({options:e}),Qe=()=>({styleClass:"p-virtualscroller-loading-icon"}),$e=(e,l)=>({rows:e,columns:l});function qe(e,l){e&1&&lt(0)}function Ge(e,l){if(e&1&&(M(0),y(1,qe,1,0,"ng-container",10),B()),e&2){let t=g(2);p(),a("ngTemplateOutlet",t.contentTemplate||t._contentTemplate)("ngTemplateOutletContext",tt(2,Mt,t.loadedItems,t.getContentOptions()))}}function Ze(e,l){e&1&&lt(0)}function Ue(e,l){if(e&1&&(M(0),y(1,Ze,1,0,"ng-container",10),B()),e&2){let t=l.$implicit,i=l.index,n=g(3);p(),a("ngTemplateOutlet",n.itemTemplate||n._itemTemplate)("ngTemplateOutletContext",tt(2,Mt,t,n.getOptions(i)))}}function Ke(e,l){if(e&1&&(X(0,"div",11,3),y(2,Ue,2,5,"ng-container",12),J()),e&2){let t=g(2);yt(t.contentStyle),v(t.cn(t.cx("content"),t.contentStyleClass)),a("pBind",t.ptm("content")),p(2),a("ngForOf",t.loadedItems)("ngForTrackBy",t._trackBy)}}function Xe(e,l){if(e&1&&Y(0,"div",13),e&2){let t=g(2);v(t.cx("spacer")),a("ngStyle",t.spacerStyle)("pBind",t.ptm("spacer"))}}function Je(e,l){e&1&&lt(0)}function Ye(e,l){if(e&1&&(M(0),y(1,Je,1,0,"ng-container",10),B()),e&2){let t=l.index,i=g(4);p(),a("ngTemplateOutlet",i.loaderTemplate||i._loaderTemplate)("ngTemplateOutletContext",xt(4,me,i.getLoaderOptions(t,i.both&&xt(2,We,i.numItemsInViewport.cols))))}}function ti(e,l){if(e&1&&(M(0),y(1,Ye,2,6,"ng-container",14),B()),e&2){let t=g(3);p(),a("ngForOf",t.loaderArr)}}function ei(e,l){e&1&&lt(0)}function ii(e,l){if(e&1&&(M(0),y(1,ei,1,0,"ng-container",10),B()),e&2){let t=g(4);p(),a("ngTemplateOutlet",t.loaderIconTemplate||t._loaderIconTemplate)("ngTemplateOutletContext",xt(3,me,Rt(2,Qe)))}}function ni(e,l){if(e&1&&(k(),Y(0,"svg",15)),e&2){let t=g(4);v(t.cx("loadingIcon")),a("spin",!0)("pBind",t.ptm("loadingIcon"))}}function oi(e,l){if(e&1&&y(0,ii,2,5,"ng-container",6)(1,ni,1,4,"ng-template",null,5,mt),e&2){let t=ut(2),i=g(3);a("ngIf",i.loaderIconTemplate||i._loaderIconTemplate)("ngIfElse",t)}}function si(e,l){if(e&1&&(X(0,"div",11),y(1,ti,2,1,"ng-container",6)(2,oi,3,2,"ng-template",null,4,mt),J()),e&2){let t=ut(3),i=g(2);v(i.cx("loader")),a("pBind",i.ptm("loader")),p(),a("ngIf",i.loaderTemplate||i._loaderTemplate)("ngIfElse",t)}}function ri(e,l){if(e&1){let t=bt();M(0),X(1,"div",7,1),Ct("scroll",function(n){ot(t);let o=g();return st(o.onContainerScroll(n))}),y(3,Ge,2,5,"ng-container",6)(4,Ke,3,7,"ng-template",null,2,mt)(6,Xe,1,4,"div",8)(7,si,4,5,"div",9),J(),B()}if(e&2){let t=ut(5),i=g();p(),v(i.cn(i.cx("root"),i.styleClass)),a("ngStyle",i._style)("pBind",i.ptm("root")),K("id",i._id)("tabindex",i.tabindex),p(2),a("ngIf",i.contentTemplate||i._contentTemplate)("ngIfElse",t),p(3),a("ngIf",i._showSpacer),p(),a("ngIf",!i.loaderDisabled&&i._showLoader&&i.d_loading)}}function li(e,l){e&1&&lt(0)}function ai(e,l){if(e&1&&(M(0),y(1,li,1,0,"ng-container",10),B()),e&2){let t=g(2);p(),a("ngTemplateOutlet",t.contentTemplate||t._contentTemplate)("ngTemplateOutletContext",tt(5,Mt,t.items,tt(2,$e,t._items,t.loadedColumns)))}}function ci(e,l){if(e&1&&(ct(0),y(1,ai,2,8,"ng-container",16)),e&2){let t=g();p(),a("ngIf",t.contentTemplate||t._contentTemplate)}}var di=`
.p-virtualscroller {
    position: relative;
    overflow: auto;
    contain: strict;
    transform: translateZ(0);
    will-change: scroll-position;
    outline: 0 none;
}

.p-virtualscroller-content {
    position: absolute;
    top: 0;
    left: 0;
    min-height: 100%;
    min-width: 100%;
    will-change: transform;
}

.p-virtualscroller-spacer {
    position: absolute;
    top: 0;
    left: 0;
    height: 1px;
    width: 1px;
    transform-origin: 0 0;
    pointer-events: none;
}

.p-virtualscroller-loader {
    position: sticky;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: dt('virtualscroller.loader.mask.background');
    color: dt('virtualscroller.loader.mask.color');
}

.p-virtualscroller-loader-mask {
    display: flex;
    align-items: center;
    justify-content: center;
}

.p-virtualscroller-loading-icon {
    font-size: dt('virtualscroller.loader.icon.size');
    width: dt('virtualscroller.loader.icon.size');
    height: dt('virtualscroller.loader.icon.size');
}

.p-virtualscroller-horizontal > .p-virtualscroller-content {
    display: flex;
}

.p-virtualscroller-inline .p-virtualscroller-content {
    position: static;
}
`,hi={root:({instance:e})=>["p-virtualscroller",{"p-virtualscroller-inline":e.inline,"p-virtualscroller-both p-both-scroll":e.both,"p-virtualscroller-horizontal p-horizontal-scroll":e.horizontal}],content:"p-virtualscroller-content",spacer:"p-virtualscroller-spacer",loader:({instance:e})=>["p-virtualscroller-loader",{"p-virtualscroller-loader-mask":!e.loaderTemplate}],loadingIcon:"p-virtualscroller-loading-icon"},pe=(()=>{class e extends ${name="virtualscroller";css=di;classes=hi;static \u0275fac=(()=>{let t;return function(n){return(t||(t=f(e)))(n||e)}})();static \u0275prov=R({token:e,factory:e.\u0275fac})}return e})();var ue=new A("SCROLLER_INSTANCE"),pi=(()=>{class e extends dt{zone;componentName="virtualScroller";bindDirectiveInstance=w(x,{self:!0});$pcScroller=w(ue,{optional:!0,skipSelf:!0})??void 0;hostName="";get id(){return this._id}set id(t){this._id=t}get style(){return this._style}set style(t){this._style=t}get styleClass(){return this._styleClass}set styleClass(t){this._styleClass=t}get tabindex(){return this._tabindex}set tabindex(t){this._tabindex=t}get items(){return this._items}set items(t){this._items=t}get itemSize(){return this._itemSize}set itemSize(t){this._itemSize=t}get scrollHeight(){return this._scrollHeight}set scrollHeight(t){this._scrollHeight=t}get scrollWidth(){return this._scrollWidth}set scrollWidth(t){this._scrollWidth=t}get orientation(){return this._orientation}set orientation(t){this._orientation=t}get step(){return this._step}set step(t){this._step=t}get delay(){return this._delay}set delay(t){this._delay=t}get resizeDelay(){return this._resizeDelay}set resizeDelay(t){this._resizeDelay=t}get appendOnly(){return this._appendOnly}set appendOnly(t){this._appendOnly=t}get inline(){return this._inline}set inline(t){this._inline=t}get lazy(){return this._lazy}set lazy(t){this._lazy=t}get disabled(){return this._disabled}set disabled(t){this._disabled=t}get loaderDisabled(){return this._loaderDisabled}set loaderDisabled(t){this._loaderDisabled=t}get columns(){return this._columns}set columns(t){this._columns=t}get showSpacer(){return this._showSpacer}set showSpacer(t){this._showSpacer=t}get showLoader(){return this._showLoader}set showLoader(t){this._showLoader=t}get numToleratedItems(){return this._numToleratedItems}set numToleratedItems(t){this._numToleratedItems=t}get loading(){return this._loading}set loading(t){this._loading=t}get autoSize(){return this._autoSize}set autoSize(t){this._autoSize=t}get trackBy(){return this._trackBy}set trackBy(t){this._trackBy=t}get options(){return this._options}set options(t){this._options=t,t&&typeof t=="object"&&(Object.entries(t).forEach(([i,n])=>this[`_${i}`]!==n&&(this[`_${i}`]=n)),Object.entries(t).forEach(([i,n])=>this[`${i}`]!==n&&(this[`${i}`]=n)))}onLazyLoad=new H;onScroll=new H;onScrollIndexChange=new H;elementViewChild;contentViewChild;height;_id;_style;_styleClass;_tabindex=0;_items;_itemSize=0;_scrollHeight;_scrollWidth;_orientation="vertical";_step=0;_delay=0;_resizeDelay=10;_appendOnly=!1;_inline=!1;_lazy=!1;_disabled=!1;_loaderDisabled=!1;_columns;_showSpacer=!0;_showLoader=!1;_numToleratedItems;_loading;_autoSize=!1;_trackBy;_options;d_loading=!1;d_numToleratedItems;contentEl;contentTemplate;itemTemplate;loaderTemplate;loaderIconTemplate;templates;_contentTemplate;_itemTemplate;_loaderTemplate;_loaderIconTemplate;first=0;last=0;page=0;isRangeChanged=!1;numItemsInViewport=0;lastScrollPos=0;lazyLoadState={};loaderArr=[];spacerStyle={};contentStyle={};scrollTimeout;resizeTimeout;initialized=!1;windowResizeListener;defaultWidth;defaultHeight;defaultContentWidth;defaultContentHeight;_contentStyleClass;get contentStyleClass(){return this._contentStyleClass}set contentStyleClass(t){this._contentStyleClass=t}get vertical(){return this._orientation==="vertical"}get horizontal(){return this._orientation==="horizontal"}get both(){return this._orientation==="both"}get loadedItems(){return this._items&&!this.d_loading?this.both?this._items.slice(this._appendOnly?0:this.first.rows,this.last.rows).map(t=>this._columns?t:Array.isArray(t)?t.slice(this._appendOnly?0:this.first.cols,this.last.cols):t):this.horizontal&&this._columns?this._items:this._items.slice(this._appendOnly?0:this.first,this.last):[]}get loadedRows(){return this.d_loading?this._loaderDisabled?this.loaderArr:[]:this.loadedItems}get loadedColumns(){return this._columns&&(this.both||this.horizontal)?this.d_loading&&this._loaderDisabled?this.both?this.loaderArr[0]:this.loaderArr:this._columns.slice(this.both?this.first.cols:this.first,this.both?this.last.cols:this.last):this._columns}_componentStyle=w(pe);constructor(t){super(),this.zone=t}onInit(){this.setInitialState()}onChanges(t){let i=!1;if(this.scrollHeight=="100%"&&(this.height="100%"),t.loading){let{previousValue:n,currentValue:o}=t.loading;this.lazy&&n!==o&&o!==this.d_loading&&(this.d_loading=o,i=!0)}if(t.orientation&&(this.lastScrollPos=this.both?{top:0,left:0}:0),t.numToleratedItems){let{previousValue:n,currentValue:o}=t.numToleratedItems;n!==o&&o!==this.d_numToleratedItems&&(this.d_numToleratedItems=o)}if(t.options){let{previousValue:n,currentValue:o}=t.options;this.lazy&&n?.loading!==o?.loading&&o?.loading!==this.d_loading&&(this.d_loading=o.loading,i=!0),n?.numToleratedItems!==o?.numToleratedItems&&o?.numToleratedItems!==this.d_numToleratedItems&&(this.d_numToleratedItems=o.numToleratedItems)}this.initialized&&!i&&(t.items?.previousValue?.length!==t.items?.currentValue?.length||t.itemSize||t.scrollHeight||t.scrollWidth)&&(this.init(),this.calculateAutoSize())}onAfterContentInit(){this.templates.forEach(t=>{switch(t.getType()){case"content":this._contentTemplate=t.template;break;case"item":this._itemTemplate=t.template;break;case"loader":this._loaderTemplate=t.template;break;case"loadericon":this._loaderIconTemplate=t.template;break;default:this._itemTemplate=t.template;break}})}onAfterViewInit(){Promise.resolve().then(()=>{this.viewInit()})}onAfterViewChecked(){this.bindDirectiveInstance.setAttrs(this.ptm("host")),this.initialized||this.viewInit()}onDestroy(){this.unbindResizeListener(),this.contentEl=null,this.initialized=!1}viewInit(){Et(this.platformId)&&!this.initialized&&Vt(this.elementViewChild?.nativeElement)&&(this.setInitialState(),this.setContentEl(this.contentEl),this.init(),this.defaultWidth=it(this.elementViewChild?.nativeElement),this.defaultHeight=et(this.elementViewChild?.nativeElement),this.defaultContentWidth=it(this.contentEl),this.defaultContentHeight=et(this.contentEl),this.initialized=!0)}init(){this._disabled||(this.bindResizeListener(),this.setSpacerSize(),setTimeout(()=>{this.setSize(),this.calculateOptions(),this.cd.detectChanges()},1))}setContentEl(t){this.contentEl=t||this.contentViewChild?.nativeElement||$t(this.elementViewChild?.nativeElement,".p-virtualscroller-content")}setInitialState(){this.first=this.both?{rows:0,cols:0}:0,this.last=this.both?{rows:0,cols:0}:0,this.numItemsInViewport=this.both?{rows:0,cols:0}:0,this.lastScrollPos=this.both?{top:0,left:0}:0,(this.d_loading===void 0||this.d_loading===!1)&&(this.d_loading=this._loading||!1),this.d_numToleratedItems=this._numToleratedItems,this.loaderArr=this.loaderArr.length>0?this.loaderArr:[]}getElementRef(){return this.elementViewChild}getPageByFirst(t){return Math.floor(((t??this.first)+this.d_numToleratedItems*4)/(this._step||1))}isPageChanged(t){return this._step?this.page!==this.getPageByFirst(t??this.first):!0}scrollTo(t){this.elementViewChild?.nativeElement?.scrollTo(t)}scrollToIndex(t,i="auto"){if(this.both?t.every(o=>o>-1):t>-1){let o=this.first,{scrollTop:s=0,scrollLeft:r=0}=this.elementViewChild?.nativeElement,{numToleratedItems:_}=this.calculateNumItems(),u=this.getContentPosition(),h=this.itemSize,T=(d=0,m)=>d<=m?0:d,I=(d,m,V)=>d*m+V,D=(d=0,m=0)=>this.scrollTo({left:d,top:m,behavior:i}),S=this.both?{rows:0,cols:0}:0,Z=!1,c=!1;this.both?(S={rows:T(t[0],_[0]),cols:T(t[1],_[1])},D(I(S.cols,h[1],u.left),I(S.rows,h[0],u.top)),c=this.lastScrollPos.top!==s||this.lastScrollPos.left!==r,Z=S.rows!==o.rows||S.cols!==o.cols):(S=T(t,_),this.horizontal?D(I(S,h,u.left),s):D(r,I(S,h,u.top)),c=this.lastScrollPos!==(this.horizontal?r:s),Z=S!==o),this.isRangeChanged=Z,c&&(this.first=S)}}scrollInView(t,i,n="auto"){if(i){let{first:o,viewport:s}=this.getRenderedRange(),r=(h=0,T=0)=>this.scrollTo({left:h,top:T,behavior:n}),_=i==="to-start",u=i==="to-end";if(_){if(this.both)s.first.rows-o.rows>t[0]?r(s.first.cols*this._itemSize[1],(s.first.rows-1)*this._itemSize[0]):s.first.cols-o.cols>t[1]&&r((s.first.cols-1)*this._itemSize[1],s.first.rows*this._itemSize[0]);else if(s.first-o>t){let h=(s.first-1)*this._itemSize;this.horizontal?r(h,0):r(0,h)}}else if(u){if(this.both)s.last.rows-o.rows<=t[0]+1?r(s.first.cols*this._itemSize[1],(s.first.rows+1)*this._itemSize[0]):s.last.cols-o.cols<=t[1]+1&&r((s.first.cols+1)*this._itemSize[1],s.first.rows*this._itemSize[0]);else if(s.last-o<=t+1){let h=(s.first+1)*this._itemSize;this.horizontal?r(h,0):r(0,h)}}}else this.scrollToIndex(t,n)}getRenderedRange(){let t=(o,s)=>s||o?Math.floor(o/(s||o)):0,i=this.first,n=0;if(this.elementViewChild?.nativeElement){let{scrollTop:o,scrollLeft:s}=this.elementViewChild.nativeElement;if(this.both)i={rows:t(o,this._itemSize[0]),cols:t(s,this._itemSize[1])},n={rows:i.rows+this.numItemsInViewport.rows,cols:i.cols+this.numItemsInViewport.cols};else{let r=this.horizontal?s:o;i=t(r,this._itemSize),n=i+this.numItemsInViewport}}return{first:this.first,last:this.last,viewport:{first:i,last:n}}}calculateNumItems(){let t=this.getContentPosition(),i=(this.elementViewChild?.nativeElement?this.elementViewChild.nativeElement.offsetWidth-t.left:0)||0,n=(this.elementViewChild?.nativeElement?this.elementViewChild.nativeElement.offsetHeight-t.top:0)||0,o=(u,h)=>h||u?Math.ceil(u/(h||u)):0,s=u=>Math.ceil(u/2),r=this.both?{rows:o(n,this._itemSize[0]),cols:o(i,this._itemSize[1])}:o(this.horizontal?i:n,this._itemSize),_=this.d_numToleratedItems||(this.both?[s(r.rows),s(r.cols)]:s(r));return{numItemsInViewport:r,numToleratedItems:_}}calculateOptions(){let{numItemsInViewport:t,numToleratedItems:i}=this.calculateNumItems(),n=(r,_,u,h=!1)=>this.getLast(r+_+(r<u?2:3)*u,h),o=this.first,s=this.both?{rows:n(this.first.rows,t.rows,i[0]),cols:n(this.first.cols,t.cols,i[1],!0)}:n(this.first,t,i);this.last=s,this.numItemsInViewport=t,this.d_numToleratedItems=i,this._showLoader&&(this.loaderArr=this.both?Array.from({length:t.rows}).map(()=>Array.from({length:t.cols})):Array.from({length:t})),this._lazy&&Promise.resolve().then(()=>{this.lazyLoadState={first:this._step?this.both?{rows:0,cols:o.cols}:0:o,last:Math.min(this._step?this._step:this.last,this._items.length)},this.handleEvents("onLazyLoad",this.lazyLoadState)})}calculateAutoSize(){this._autoSize&&!this.d_loading&&Promise.resolve().then(()=>{if(this.contentEl){this.contentEl.style.minHeight=this.contentEl.style.minWidth="auto",this.contentEl.style.position="relative",this.elementViewChild.nativeElement.style.contain="none";let[t,i]=[it(this.contentEl),et(this.contentEl)];t!==this.defaultContentWidth&&(this.elementViewChild.nativeElement.style.width=""),i!==this.defaultContentHeight&&(this.elementViewChild.nativeElement.style.height="");let[n,o]=[it(this.elementViewChild.nativeElement),et(this.elementViewChild.nativeElement)];(this.both||this.horizontal)&&(this.elementViewChild.nativeElement.style.width=n<this.defaultWidth?n+"px":this._scrollWidth||this.defaultWidth+"px"),(this.both||this.vertical)&&(this.elementViewChild.nativeElement.style.height=o<this.defaultHeight?o+"px":this._scrollHeight||this.defaultHeight+"px"),this.contentEl.style.minHeight=this.contentEl.style.minWidth="",this.contentEl.style.position="",this.elementViewChild.nativeElement.style.contain=""}})}getLast(t=0,i=!1){return this._items?Math.min(i?(this._columns||this._items[0]).length:this._items.length,t):0}getContentPosition(){if(this.contentEl){let t=getComputedStyle(this.contentEl),i=parseFloat(t.paddingLeft)+Math.max(parseFloat(t.left)||0,0),n=parseFloat(t.paddingRight)+Math.max(parseFloat(t.right)||0,0),o=parseFloat(t.paddingTop)+Math.max(parseFloat(t.top)||0,0),s=parseFloat(t.paddingBottom)+Math.max(parseFloat(t.bottom)||0,0);return{left:i,right:n,top:o,bottom:s,x:i+n,y:o+s}}return{left:0,right:0,top:0,bottom:0,x:0,y:0}}setSize(){if(this.elementViewChild?.nativeElement){let t=this.elementViewChild.nativeElement,i=t.parentElement?.parentElement,n=t.offsetWidth,o=i?.offsetWidth||0,s=this._scrollWidth||`${n||o}px`,r=t.offsetHeight,_=i?.offsetHeight||0,u=this._scrollHeight||`${r||_}px`,h=(T,I)=>t.style[T]=I;this.both||this.horizontal?(h("height",u),h("width",s)):h("height",u)}}setSpacerSize(){if(this._items){let t=this.getContentPosition(),i=(n,o,s,r=0)=>this.spacerStyle=kt(_t({},this.spacerStyle),{[`${n}`]:(o||[]).length*s+r+"px"});this.both?(i("height",this._items,this._itemSize[0],t.y),i("width",this._columns||this._items[1],this._itemSize[1],t.x)):this.horizontal?i("width",this._columns||this._items,this._itemSize,t.x):i("height",this._items,this._itemSize,t.y)}}setContentPosition(t){if(this.contentEl&&!this._appendOnly){let i=t?t.first:this.first,n=(s,r)=>s*r,o=(s=0,r=0)=>this.contentStyle=kt(_t({},this.contentStyle),{transform:`translate3d(${s}px, ${r}px, 0)`});if(this.both)o(n(i.cols,this._itemSize[1]),n(i.rows,this._itemSize[0]));else{let s=n(i,this._itemSize);this.horizontal?o(s,0):o(0,s)}}}onScrollPositionChange(t){let i=t.target;if(!i)throw new Error("Event target is null");let n=this.getContentPosition(),o=(c,d)=>c?c>d?c-d:c:0,s=(c,d)=>d||c?Math.floor(c/(d||c)):0,r=(c,d,m,V,O,U)=>c<=O?O:U?m-V-O:d+O-1,_=(c,d,m,V,O,U,gt)=>c<=U?0:Math.max(0,gt?c<d?m:c-U:c>d?m:c-2*U),u=(c,d,m,V,O,U=!1)=>{let gt=d+V+2*O;return c>=O&&(gt+=O+1),this.getLast(gt,U)},h=o(i.scrollTop,n.top),T=o(i.scrollLeft,n.left),I=this.both?{rows:0,cols:0}:0,D=this.last,S=!1,Z=this.lastScrollPos;if(this.both){let c=this.lastScrollPos.top<=h,d=this.lastScrollPos.left<=T;if(!this._appendOnly||this._appendOnly&&(c||d)){let m={rows:s(h,this._itemSize[0]),cols:s(T,this._itemSize[1])},V={rows:r(m.rows,this.first.rows,this.last.rows,this.numItemsInViewport.rows,this.d_numToleratedItems[0],c),cols:r(m.cols,this.first.cols,this.last.cols,this.numItemsInViewport.cols,this.d_numToleratedItems[1],d)};I={rows:_(m.rows,V.rows,this.first.rows,this.last.rows,this.numItemsInViewport.rows,this.d_numToleratedItems[0],c),cols:_(m.cols,V.cols,this.first.cols,this.last.cols,this.numItemsInViewport.cols,this.d_numToleratedItems[1],d)},D={rows:u(m.rows,I.rows,this.last.rows,this.numItemsInViewport.rows,this.d_numToleratedItems[0]),cols:u(m.cols,I.cols,this.last.cols,this.numItemsInViewport.cols,this.d_numToleratedItems[1],!0)},S=I.rows!==this.first.rows||D.rows!==this.last.rows||I.cols!==this.first.cols||D.cols!==this.last.cols||this.isRangeChanged,Z={top:h,left:T}}}else{let c=this.horizontal?T:h,d=this.lastScrollPos<=c;if(!this._appendOnly||this._appendOnly&&d){let m=s(c,this._itemSize),V=r(m,this.first,this.last,this.numItemsInViewport,this.d_numToleratedItems,d);I=_(m,V,this.first,this.last,this.numItemsInViewport,this.d_numToleratedItems,d),D=u(m,I,this.last,this.numItemsInViewport,this.d_numToleratedItems),S=I!==this.first||D!==this.last||this.isRangeChanged,Z=c}}return{first:I,last:D,isRangeChanged:S,scrollPos:Z}}onScrollChange(t){let{first:i,last:n,isRangeChanged:o,scrollPos:s}=this.onScrollPositionChange(t);if(o){let r={first:i,last:n};if(this.setContentPosition(r),this.first=i,this.last=n,this.lastScrollPos=s,this.handleEvents("onScrollIndexChange",r),this._lazy&&this.isPageChanged(i)){let _={first:this._step?Math.min(this.getPageByFirst(i)*this._step,this._items.length-this._step):i,last:Math.min(this._step?(this.getPageByFirst(i)+1)*this._step:n,this._items.length)};(this.lazyLoadState.first!==_.first||this.lazyLoadState.last!==_.last)&&this.handleEvents("onLazyLoad",_),this.lazyLoadState=_}}}onContainerScroll(t){if(this.handleEvents("onScroll",{originalEvent:t}),this._delay){if(this.scrollTimeout&&clearTimeout(this.scrollTimeout),!this.d_loading&&this._showLoader){let{isRangeChanged:i}=this.onScrollPositionChange(t);(i||(this._step?this.isPageChanged():!1))&&(this.d_loading=!0,this.cd.detectChanges())}this.scrollTimeout=setTimeout(()=>{this.onScrollChange(t),this.d_loading&&this._showLoader&&(!this._lazy||this._loading===void 0)&&(this.d_loading=!1,this.page=this.getPageByFirst()),this.cd.detectChanges()},this._delay)}else!this.d_loading&&this.onScrollChange(t)}bindResizeListener(){Et(this.platformId)&&(this.windowResizeListener||this.zone.runOutsideAngular(()=>{let t=this.document.defaultView,i=qt()?"orientationchange":"resize";this.windowResizeListener=this.renderer.listen(t,i,this.onWindowResize.bind(this))}))}unbindResizeListener(){this.windowResizeListener&&(this.windowResizeListener(),this.windowResizeListener=null)}onWindowResize(){this.resizeTimeout&&clearTimeout(this.resizeTimeout),this.resizeTimeout=setTimeout(()=>{if(Vt(this.elementViewChild?.nativeElement)){let[t,i]=[it(this.elementViewChild?.nativeElement),et(this.elementViewChild?.nativeElement)],[n,o]=[t!==this.defaultWidth,i!==this.defaultHeight];(this.both?n||o:this.horizontal?n:this.vertical?o:!1)&&this.zone.run(()=>{this.d_numToleratedItems=this._numToleratedItems,this.defaultWidth=t,this.defaultHeight=i,this.defaultContentWidth=it(this.contentEl),this.defaultContentHeight=et(this.contentEl),this.init()})}},this._resizeDelay)}handleEvents(t,i){return this.options&&this.options[t]?this.options[t](i):this[t].emit(i)}getContentOptions(){return{contentStyleClass:`p-virtualscroller-content ${this.d_loading?"p-virtualscroller-loading":""}`,items:this.loadedItems,getItemOptions:t=>this.getOptions(t),loading:this.d_loading,getLoaderOptions:(t,i)=>this.getLoaderOptions(t,i),itemSize:this._itemSize,rows:this.loadedRows,columns:this.loadedColumns,spacerStyle:this.spacerStyle,contentStyle:this.contentStyle,vertical:this.vertical,horizontal:this.horizontal,both:this.both,scrollTo:this.scrollTo.bind(this),scrollToIndex:this.scrollToIndex.bind(this),orientation:this._orientation,scrollableElement:this.elementViewChild?.nativeElement}}getOptions(t){let i=(this._items||[]).length,n=this.both?this.first.rows+t:this.first+t;return{index:n,count:i,first:n===0,last:n===i-1,even:n%2===0,odd:n%2!==0}}getLoaderOptions(t,i){let n=this.loaderArr.length;return _t({index:t,count:n,first:t===0,last:t===n-1,even:t%2===0,odd:t%2!==0,loading:this.d_loading},i)}static \u0275fac=function(i){return new(i||e)(Nt(Lt))};static \u0275cmp=b({type:e,selectors:[["p-scroller"],["p-virtualscroller"],["p-virtual-scroller"],["p-virtualScroller"]],contentQueries:function(i,n,o){if(i&1&&(P(o,he,4),P(o,Pe,4),P(o,Re,4),P(o,Ae,4),P(o,wt,4)),i&2){let s;z(s=E())&&(n.contentTemplate=s.first),z(s=E())&&(n.itemTemplate=s.first),z(s=E())&&(n.loaderTemplate=s.first),z(s=E())&&(n.loaderIconTemplate=s.first),z(s=E())&&(n.templates=s)}},viewQuery:function(i,n){if(i&1&&(pt(He,5),pt(he,5)),i&2){let o;z(o=E())&&(n.elementViewChild=o.first),z(o=E())&&(n.contentViewChild=o.first)}},hostVars:2,hostBindings:function(i,n){i&2&&Pt("height",n.height)},inputs:{hostName:"hostName",id:"id",style:"style",styleClass:"styleClass",tabindex:"tabindex",items:"items",itemSize:"itemSize",scrollHeight:"scrollHeight",scrollWidth:"scrollWidth",orientation:"orientation",step:"step",delay:"delay",resizeDelay:"resizeDelay",appendOnly:"appendOnly",inline:"inline",lazy:"lazy",disabled:"disabled",loaderDisabled:"loaderDisabled",columns:"columns",showSpacer:"showSpacer",showLoader:"showLoader",numToleratedItems:"numToleratedItems",loading:"loading",autoSize:"autoSize",trackBy:"trackBy",options:"options"},outputs:{onLazyLoad:"onLazyLoad",onScroll:"onScroll",onScrollIndexChange:"onScrollIndexChange"},features:[W([pe,{provide:ue,useExisting:e},{provide:q,useExisting:e}]),j([x]),C],ngContentSelectors:je,decls:3,vars:2,consts:[["disabledContainer",""],["element",""],["buildInContent",""],["content",""],["buildInLoader",""],["buildInLoaderIcon",""],[4,"ngIf","ngIfElse"],[3,"scroll","ngStyle","pBind"],[3,"class","ngStyle","pBind",4,"ngIf"],[3,"class","pBind",4,"ngIf"],[4,"ngTemplateOutlet","ngTemplateOutletContext"],[3,"pBind"],[4,"ngFor","ngForOf","ngForTrackBy"],[3,"ngStyle","pBind"],[4,"ngFor","ngForOf"],["data-p-icon","spinner",3,"spin","pBind"],[4,"ngIf"]],template:function(i,n){if(i&1&&(at(),y(0,ri,8,10,"ng-container",6)(1,ci,2,1,"ng-template",null,0,mt)),i&2){let o=ut(2);a("ngIf",!n._disabled)("ngIfElse",o)}},dependencies:[Q,Wt,vt,It,Qt,Xt,L,x],encapsulation:2})}return e})(),Un=(()=>{class e{static \u0275fac=function(i){return new(i||e)};static \u0275mod=rt({type:e});static \u0275inj=nt({imports:[pi,L,L]})}return e})();export{mi as a,_i as b,yi as c,wi as d,se as e,Xi as f,mn as g,zn as h,pi as i,Un as j};
